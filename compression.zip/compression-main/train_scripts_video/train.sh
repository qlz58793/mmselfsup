
name=elicho-m4096
export CUDA_VISIBLE_DEVICES="0"
python train.py \
-c ./cfgs/${name}.yml \
-c ./cfgs/train_default_server38.yml \
--save_name ${name} \
--ckpt_path

#name=dvcplus-m512
#export CUDA_VISIBLE_DEVICES="3"
#python train.py \
#-c ./cfgs/${name}.yml \
#-c ./cfgs/train_dvcplus.yml \
#-c ./cfgs/train_video_server38.yml \
#--last_iter 0 \
#--save_name ${name}