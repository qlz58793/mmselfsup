import shutil
import time
import glob
import math
import abc

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd.profiler as profiler
from typing import Tuple, List, Dict
from collections import defaultdict, OrderedDict
from pathlib import Path
import json
import copy

from data_compression.entropy_models import \
    ContinuousUnconditionalEntropyModel, ContinuousConditionalEntropyModel
from data_compression.distributions.uniform_noised import \
    NoisyDeepFactorized, NoisyNormal
from data_compression.quantization import UniformQuantization
from data_compression.layers import MaskedConv2d, Downsample, Upsample
import data_compression.ops as ops
from data_compression.layers import GDN
import data_compression.utils as utils
from pytorch_msssim import ms_ssim
from data_compression.layers.compressai import AttentionBlock

from .intra import ELICModel, ELICHyperModel
from .optical_flow import flow_sample, Spynet

Tensor = torch.Tensor


def mse_loss(x, x_hat):
    return ((x - x_hat) ** 2).mean()


def msssim_loss(x, x_hat, data_range=1.):
    return 1 - ms_ssim(x, x_hat, data_range=data_range)


def clamp(x, min=None, max=None):
    if min is not None:
        x = ops.lower_bound(x, min)
    if max is not None:
        x = ops.upper_bound(x, max)
    return x


def set_requires_grad(model, requires_grad):
    for param in model.parameters():
        param.requires_grad = requires_grad


class VideoCodingModelBase(nn.Module, metaclass=abc.ABCMeta):
    metric_table = ["mse", "ms-ssim"]
    gop_config_keys = ["Type", "POC"]
    # intra_period = None

    def __init__(self,
                 metric: str = "mse",
                 *,
                 gop_config: List[OrderedDict] = None,
                 ):
        super().__init__()
        # training metric
        self.metric = metric
        self.gop_config = gop_config
        self.check_gop_config()
        print(gop_config)

    def check_gop_config(self):
        for frame_config in self.gop_config:
            keys = frame_config.keys()
            assert sorted(keys) == sorted(self.gop_config_keys)

    @property
    def gop_size(self):
        return len(self.gop_config)

    @property
    def metric_fn(self):
        assert self.metric in self.metric_table
        metric_fn = None
        if self.metric == "mse":
            metric_fn = mse_loss
        elif self.metric == "ms-ssim":
            metric_fn = msssim_loss
        return metric_fn

    @abc.abstractmethod
    def forward(self, x: List[Tensor], training: bool):
        raise NotImplementedError

    @abc.abstractmethod
    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
		"""
        raise NotImplementedError

    @abc.abstractmethod
    def compress(self, x: Tensor) -> List[str]:
        """Compress `x` into byte strings.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def decompress(self, strings: List[str], wdt: int, hgt: int) -> Tensor:
        """Decompress `x` given byte strings
        """
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        raise NotImplementedError

    @property
    def device(self):
        return next(self.parameters()).device

    def pre_padding(self, x):
        hgt, wdt = x.shape[2:4]
        factor = self.downscale_factor
        dh = factor * math.ceil(hgt / factor) - hgt
        dw = factor * math.ceil(wdt / factor) - wdt
        x = F.pad(x, (dw//2, dw//2 + dw%2, dh//2, dh//2 + dh%2))
        return x

    def post_cropping(self, x, wdt, hgt):
        factor = self.downscale_factor
        dh = factor * math.ceil(hgt / factor) - hgt
        dw = factor * math.ceil(wdt / factor) - wdt
        return x[..., dh//2: -(dh//2 + dh%2) or None, \
                            dw//2: -(dw//2 + dw%2) or  None]

    def build_poc_list(self, n_frames):
        gop_config = self.gop_config
        gop_size = self.gop_size
        n_gops = (n_frames - 1) // gop_size + 1
        poc_list = [0]
        for i_gop in range(n_gops):
            for i_rec in range(gop_size):
                poc = i_gop * gop_size + gop_config[i_rec]["POC"]
                if poc < n_frames:
                    poc_list.append(poc)
        assert len(poc_list) == n_frames
        return poc_list

    @torch.no_grad()
    def evaluate(self, input_glob, output_dir=None, save_rec=False,
                 n_frames_per_sequence=None):
        input_ps = glob.glob(input_glob)

        if output_dir is not None:
            output_dir = Path(output_dir)
            shutil.rmtree(output_dir, ignore_errors=True)
            output_dir.mkdir(exist_ok=True, parents=True)

        logouts = []
        torch.cuda.empty_cache()
        self.evaluate_one_file(
            input_ps[0], output_dir, False, n_frames_per_sequence)
        for i, input_p in enumerate(input_ps):
            logouts.append(self.evaluate_one_file(
                input_p, output_dir, save_rec, n_frames_per_sequence))
        torch.cuda.empty_cache()

        results =  defaultdict(float)
        for i in range(len(input_ps)):
            for k, v in logouts[i].items():
                results[k] += float(v) / len(input_ps)

        if output_dir is not None:
            json_results = {}
            json_results["num_files"] = len(input_ps)
            json_results["n_frames_per_sequence"] = n_frames_per_sequence
            json_results.update(results)
            with open(output_dir / 'results.json', "w") as f:
                json.dump(json_results, f, indent=4)

        log_str = [f"n_seqs: {len(input_ps)}"]
        log_str += [f"n_frames_per_seq: {n_frames_per_sequence}"]
        log_str += [f"{k}: {v:.6f}" for k, v in results.items()]
        log_str = ", ".join(log_str)
        return results["rd_loss"], log_str

    @torch.no_grad()
    def evaluate_one_file(self, input_p, output_dir=None, save_rec=False,
                          n_frames=None):
        device = self.device
        input_p = Path(input_p)

        assert input_p.is_dir()
        frame_ps = sorted(input_p.iterdir())
        n_frames = len(frame_ps) if n_frames is None else n_frames
        frame_ps = frame_ps[:n_frames]
        assert len(frame_ps) == n_frames

        logout = defaultdict(float)
        enable_profile = False
        skip_intra = False
        ref = None

        poc_list = self.build_poc_list(n_frames)
        for poc in poc_list:
            frame_p = frame_ps[poc]
            ori = utils.load_file(frame_p)
            hgt, wdt = ori.shape[2:4]
            ori = torch.from_numpy(ori).to(device)
            if poc == 0 and skip_intra:
                n_frames -= 1
                ref = ori
                continue

            rec = ori.to(torch.float32).div(255.)
            rec = self.pre_padding(rec)
            if ref is not None:
                ref = ref.to(torch.float32).div(255.)
                ref = self.pre_padding(ref)

            torch.cuda.synchronize()
            t0 = time.time()
            with profiler.profile(enable_profile,
                                  use_cuda=True, profile_memory=True) as prof:
                rec, bits_list = self.forward_one_frame(
                    poc, rec, ref, return_loss=False)
            torch.cuda.synchronize()
            t1 = time.time()

            rec = self.post_cropping(rec, wdt, hgt)
            rec = rec.clamp(0, 1).mul(255.).round().to(torch.uint8)
            ref = rec

            # evaluation
            bits = sum(bits_list)
            bpp = bits / hgt / wdt
            rd_loss = self.rd_loss(ori, rec, bits, data_range=255.)
            psnr, msssim, _, _ = utils.measure_quality_torch(ori, rec)
            
            # save reconstruction
            if output_dir is not None and save_rec:
                rec = rec.cpu().numpy()
                suffix = ".png"
                frame_stem = [
                    frame_p.stem,
                    f"bpp{bpp:.4f}",
                    f"psnr{psnr:.2f}",
                    f"msssim{msssim:.4f}"
                ]
                frame_stem = "_".join(frame_stem)
                rec_name = frame_stem + suffix
                seq_stem = input_p.stem
                rec_p = output_dir / seq_stem / rec_name
                rec_p.parent.mkdir(parents=True, exist_ok=True)
                utils.save_file(rec, rec_p)

            logout["rd_loss"] += rd_loss
            logout["bpp"] += bpp
            logout["psnr"] += psnr
            logout["ms-ssim"] += msssim
            logout["fw-time"] += t1 - t0

        if enable_profile:
            print(prof.key_averages().table(
                sort_by="cuda_time",
                row_limit=50,
                top_level_events_only=True
            ))

        for k, v in logout.items():
            logout[k] = v / n_frames
        return logout


class ResidualBottleneckBlock(nn.Module):
    def __init__(self, depth, ks=3):
        super().__init__()
        self.m = nn.Sequential(
            nn.Conv2d(depth, depth//2, 1, 1, 0),
            nn.ReLU(),
            nn.Conv2d(depth//2, depth//2, ks, 1, ks//2),
            nn.ReLU(),
            nn.Conv2d(depth//2, depth, 1, 1, 0),
        )
    def forward(self, x):
        return x + self.m(x)


class MotionCodingModel(ELICModel):

    def __init__(self, in_depth, out_depth, N=64, M=64,
                 slice_depths=(32, 32),**kwargs):
        super().__init__(N=N, M=M, slice_depths=slice_depths, **kwargs)
        k = 3
        self.g_a = nn.Sequential(
            Downsample(in_depth, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            AttentionBlock(N),
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Downsample(N, M),
            AttentionBlock(M)
        )
        self.g_s = nn.Sequential(
            AttentionBlock(M),
            Upsample(M, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, N),
            AttentionBlock(N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, out_depth)
        )


class ResidualCodingModel(ELICModel):

    def __init__(self, in_depth, out_depth, N=128, M=192,
                 slice_depths=(96, 96), **kwargs):
        super().__init__(N=N, M=M, slice_depths=slice_depths, **kwargs)
        k = 3
        self.g_a = nn.Sequential(
            Downsample(in_depth, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            AttentionBlock(N),
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Downsample(N, M),
            AttentionBlock(M)
        )
        self.g_s = nn.Sequential(
            AttentionBlock(M),
            Upsample(M, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, N),
            AttentionBlock(N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(k)],
            Upsample(N, out_depth)
        )


# class IntraMotionResidualCodingModel(VideoCodingModelBase):
class DVCplusModel(VideoCodingModelBase):
    """
    """
    loss_mode_table = [
        "IP-single-0", "IP-single-1", "IP-single-2", "IP-single-3",
        "IP-single-4", "IPP-single-0", "IPPPP-single-0", "IPPPP-all-0"
    ]

    def __init__(self, lmbda=None, loss_mode=None, **kwargs):
        super().__init__(**kwargs)
        self.intra_codec = ELICHyperModel()
        self.motion_codec= MotionCodingModel(in_depth=2, out_depth=2)
        self.residual_codec = ResidualCodingModel(in_depth=3, out_depth=3)
        self.motion_estimation = Spynet()
        self.motion_compensation = MotionCompensation()
        # dynamic training settings
        self.lmbda = lmbda
        self.loss_mode = loss_mode

    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss

    def forward(self, x, return_loss=True):
        assert return_loss
        freeze_me = True
        freeze_mc = False

        n_frames = len(x)
        if "IP" in self.loss_mode:
            n_frames = 2
        if "IPP" in self.loss_mode:
            n_frames = 3
        if "IPPPP" in self.loss_mode:
            n_frames = 5
        assert n_frames <= len(x)

        if self.loss_mode in ["IP-single-2", "IP-single-3"]:
            freeze_mc = True

        set_requires_grad(self.intra_codec, False)
        set_requires_grad(self.motion_estimation, not freeze_me)
        set_requires_grad(self.motion_codec, not freeze_mc)

        ref = None
        losses = []
        for poc in range(n_frames):
            loss, cur_hat = self.forward_one_frame(poc, x[poc], ref, True)
            losses.append(loss)
            ref = cur_hat

        if "single" in self.loss_mode:
            losses = losses[-1:]
        return sum(losses)

    def forward_one_frame(self, poc, cur, ref=None, return_loss=True):
        if poc == 0:
            with torch.no_grad():
                cur_hat, bits_list = self.intra_codec(cur, False)
        else:
            assert ref is not None

            with profiler.record_function(f"poc{poc}-me"):
                m = self.motion_estimation(cur, ref)
            with profiler.record_function(f"poc{poc}-mc"):
                m_hat, m_bits_list = self.motion_codec(m, False)

            if self.loss_mode == "IP-single-0":
                cur_hat = flow_sample(ref, m_hat)
                bits_list = m_bits_list
                if return_loss:
                    loss = self.rd_loss(cur, cur_hat, sum(bits_list).detach())
                    return loss, cur_hat
                else:
                    return cur_hat, bits_list

            if self.loss_mode == "IP-single-1":
                cur_hat = flow_sample(ref, m_hat)
                bits_list = m_bits_list
                if return_loss:
                    loss = self.rd_loss(cur, cur_hat, sum(bits_list))
                    return loss, cur_hat
                else:
                    return cur_hat, bits_list

            with profiler.record_function(f"poc{poc}-mcp"):
                # cur_bar = flow_sample(ref, m_hat)
                cur_bar = self.motion_compensation(ref, m_hat)
            with profiler.record_function(f"poc{poc}-rc"):
                r = cur - cur_bar
                r_hat, r_bits_list = self.residual_codec(r, False)
                cur_hat = cur_bar + r_hat
            bits_list = m_bits_list + r_bits_list

            if self.loss_mode == "IP-single-2":
                if return_loss:
                    loss = self.rd_loss(cur, cur_hat, sum(bits_list).detach())
                    return loss, cur_hat
                else:
                    return cur_hat, bits_list

        if return_loss:
            loss = self.rd_loss(cur, cur_hat, sum(bits_list))
            return loss, cur_hat
        else:
            return cur_hat, bits_list

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass

    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, shape):
        """Decompress an image `x` given byte strings
        """
        pass

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


class DownSamplingBlock(nn.Module):

    def __init__(self, ch_in, ch_out):
        super().__init__()
        self.f = nn.Sequential(
            nn.PReLU(),
            nn.Conv2d(ch_in, ch_out, kernel_size = 3, stride = 2, padding = 1),
            nn.PReLU(),
            nn.Conv2d(ch_out, ch_out, kernel_size = 3, padding = 1)
        )

    def forward(self, x):
        return self.f(x)


class UpSamplingBlock(nn.Module):

    def __init__(self, ch_in, ch_out):
        super().__init__()
        self.f = nn.Sequential(
            nn.Upsample(scale_factor = 2, mode = 'bilinear', align_corners = False),
            nn.PReLU(),
            nn.Conv2d(ch_in, ch_out, kernel_size = 3, padding = 1),
            nn.PReLU(),
            nn.Conv2d(ch_out, ch_out, kernel_size = 3, padding = 1)
        )

    def forward(self, x):
        return self.f(x)


class LateralBlock(nn.Module):

    def __init__(self, ch_in, ch_out):
        super().__init__()
        self.f = nn.Sequential(
            nn.PReLU(),
            nn.Conv2d(ch_in, ch_out, kernel_size=3, padding=1),
            nn.PReLU(),
            nn.Conv2d(ch_out, ch_out, kernel_size=3, padding=1)
        )
        if ch_in != ch_out:
            self.conv = nn.Conv2d(ch_in, ch_out, kernel_size=3, padding=1)

    def forward(self, x):
        fx = self.f(x)
        if fx.shape[1] != x.shape[1]:
            x = self.conv(x)

        return fx + x


class MotionCompensation(nn.Module):

    def __init__(self):
        super().__init__()
        n_rows = 3
        n_cols = 6
        depths = (32, 64, 96)

        def down_layer(in_depth, out_depth):
            return DownSamplingBlock(in_depth, out_depth)
            # return nn.Sequential(
            #     Downsample(in_depth, out_depth),
            #     ResidualBottleneckBlock(out_depth),
            #     ResidualBottleneckBlock(out_depth)
            # )

        def up_layer(in_depth, out_depth):
            return UpSamplingBlock(in_depth, out_depth)
            # return nn.Sequential(
            #     ResidualBottleneckBlock(in_depth),
            #     ResidualBottleneckBlock(in_depth),
            #     Upsample(in_depth, out_depth),
            # )

        def lateral_layer(depth):
            return LateralBlock(depth, depth)
            # return nn.Sequential(
            #     ResidualBottleneckBlock(depth),
            #     ResidualBottleneckBlock(depth),
            # )

        # GridNet:  "0x0" means feature at "{row}x{col}", "up" means upscale,
        # "up" means upscale, and "->" means lateral.
        # in0 -> 0x0 -> 0x1 -> 0x2 -> 0x3 -> 0x4 -> 0x5 -> out
        #        down   down   down   up     up     up
        # in1 -> 1x0 -> 1x1 -> 1x2 -> 1x3 -> 1x4 -> 1x5
        #        down   down   down   up     up     up
        # in2 -> 2x0 -> 2x1 -> 2x2 -> 2x3 -> 2x4 -> 2x5
        self.lateral_in0_0x0 = nn.Sequential(
            nn.Conv2d(3+3+2, depths[0], 3, 1, 1),
            lateral_layer(depths[0]))
        self.lateral_in1_1x0 = nn.Sequential()
        self.lateral_in2_2x0 = nn.Sequential()
        self.lateral_0x5_out = nn.Sequential(
            lateral_layer(depths[0]),
            nn.Conv2d(depths[0], 3, 3, 1, 1))

        self.down_0x0_1x0 = down_layer(depths[0], depths[1])
        self.down_1x0_2x0 = down_layer(depths[1], depths[2])
        self.down_0x1_1x1 = down_layer(depths[0], depths[1])
        self.down_1x1_2x1 = down_layer(depths[1], depths[2])
        self.down_0x2_1x2 = down_layer(depths[0], depths[1])
        self.down_1x2_2x2 = down_layer(depths[1], depths[2])

        self.up_2x3_1x3 = up_layer(depths[2], depths[1])
        self.up_1x3_0x3 = up_layer(depths[1], depths[0])
        self.up_2x4_1x4 = up_layer(depths[2], depths[1])
        self.up_1x4_0x4 = up_layer(depths[1], depths[0])
        self.up_2x5_1x5 = up_layer(depths[2], depths[1])
        self.up_1x5_0x5 = up_layer(depths[1], depths[0])

        self.lateral_0x0_0x1 = lateral_layer(depths[0])
        self.lateral_0x1_0x2 = lateral_layer(depths[0])
        self.lateral_0x2_0x3 = lateral_layer(depths[0])
        self.lateral_0x3_0x4 = lateral_layer(depths[0])
        self.lateral_0x4_0x5 = lateral_layer(depths[0])

        self.lateral_1x0_1x1 = lateral_layer(depths[1])
        self.lateral_1x1_1x2 = lateral_layer(depths[1])
        self.lateral_1x2_1x3 = lateral_layer(depths[1])
        self.lateral_1x3_1x4 = lateral_layer(depths[1])
        self.lateral_1x4_1x5 = lateral_layer(depths[1])

        self.lateral_2x0_2x1 = lateral_layer(depths[2])
        self.lateral_2x1_2x2 = lateral_layer(depths[2])
        self.lateral_2x2_2x3 = lateral_layer(depths[2])
        self.lateral_2x3_2x4 = lateral_layer(depths[2])
        self.lateral_2x4_2x5 = lateral_layer(depths[2])

    def forward(self, ref, motion):
        # warping
        ref = torch.cat([flow_sample(ref, motion), ref, motion], dim=1)
        # grid net
        x = [ref, 0, 0] # column state

        x[0] = self.lateral_in0_0x0(x[0])
        x[1] = self.lateral_in1_1x0(x[1]) + self.down_0x0_1x0(x[0])
        x[2] = self.lateral_in2_2x0(x[2]) + self.down_1x0_2x0(x[1])

        x[0] = self.lateral_0x0_0x1(x[0])
        x[1] = self.lateral_1x0_1x1(x[1]) + self.down_0x1_1x1(x[0])
        x[2] = self.lateral_2x0_2x1(x[2]) + self.down_1x1_2x1(x[1])

        x[0] = self.lateral_0x1_0x2(x[0])
        x[1] = self.lateral_1x1_1x2(x[1]) + self.down_0x2_1x2(x[0])
        x[2] = self.lateral_2x1_2x2(x[2]) + self.down_1x2_2x2(x[1])

        x[2] = self.lateral_2x2_2x3(x[2])
        x[1] = self.lateral_1x2_1x3(x[1]) + self.up_2x3_1x3(x[2])
        x[0] = self.lateral_0x2_0x3(x[0]) + self.up_1x3_0x3(x[1])

        x[2] = self.lateral_2x3_2x4(x[2])
        x[1] = self.lateral_1x3_1x4(x[1]) + self.up_2x4_1x4(x[2])
        x[0] = self.lateral_0x3_0x4(x[0]) + self.up_1x4_0x4(x[1])

        x[2] = self.lateral_2x4_2x5(x[2])
        x[1] = self.lateral_1x4_1x5(x[1]) + self.up_2x5_1x5(x[2])
        x[0] = self.lateral_0x4_0x5(x[0]) + self.up_1x5_0x5(x[1])

        x[0] = self.lateral_0x5_out(x[0])
        return x[0]


