import torch
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path

grid_buffer = {}


def flow_sample(src, flow):
	hgt, wdt = src.shape[-2:]
	device = src.device
	dtype = src.dtype
	grid_name = f"{device}-{flow.shape[-1]}x{flow.shape[-2]}"
	if grid_name not in grid_buffer:
		grid_w = torch.linspace(-1, 1, wdt, device=device, dtype=dtype)
		gird_h = torch.linspace(-1, 1, hgt, device=device, dtype=dtype)
		gird_h, grid_w = torch.meshgrid(gird_h, grid_w, indexing="ij")
		grid = torch.stack((grid_w, gird_h), 0).unsqueeze(0)
		grid_buffer[grid_name] = grid

	norm = torch.tensor([wdt - 1, hgt - 1], device=device, dtype=dtype)
	norm = norm.clamp(min=1).view(1, -1, 1, 1)
	flow = flow * 2. / norm
	flow = flow + grid_buffer[grid_name]

	output = F.grid_sample(
		src, flow.permute(0, 2, 3, 1),
		padding_mode="border",
		align_corners=True
	)
	return output


def bilinear_upscale(input):
	return F.interpolate(
		input, scale_factor=2, mode='bilinear', align_corners=False)


class SpynetUnit(torch.nn.Module):
	def __init__(self):
		super().__init__()
		self.module = torch.nn.Sequential(
			torch.nn.Conv2d(8, 32, 7, 1, 3),
			torch.nn.ReLU(),
			torch.nn.Conv2d(32, 64, 7, 1, 3),
			torch.nn.ReLU(),
			torch.nn.Conv2d(64, 32, 7, 1, 3),
			torch.nn.ReLU(),
			torch.nn.Conv2d(32, 16, 7, 1, 3),
			torch.nn.ReLU(),
			torch.nn.Conv2d(16, 2, 7, 1, 3)
		)

	def forward(self, img1, img2, flow):
		img1_bar = flow_sample(img2, flow)
		flow = torch.cat([img1, img1_bar, flow], 1)
		flow = self.module(flow)
		return flow


class Spynet(torch.nn.Module):
	def __init__(self, n_levels=6):
		super().__init__()
		self.n_levels = n_levels
		self.module = nn.ModuleList([SpynetUnit() for _ in range(n_levels)])
		self.load_from_pretrained()

	def load_from_pretrained(self):
		pretrained_p = Path(__file__).resolve().parent / "spynet.pth"
		state_dict = torch.load(pretrained_p)
		state_dict = {k.replace("Basic", ""): v for k, v in state_dict.items()}
		self.load_state_dict(state_dict, strict=True)

	def pre_process(self, img):
		img = img.flip(1)
		mean = img.new_tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
		std = img.new_tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
		img = (img - mean) / std
		return img

	def forward(self, img1, img2):
		imgs1 = [self.pre_process(img1)]
		imgs2 = [self.pre_process(img2)]
		for lv in range(self.n_levels - 1):
			imgs1.insert(0, F.avg_pool2d(imgs1[0], kernel_size=2, stride=2))
			imgs2.insert(0, F.avg_pool2d(imgs2[0], kernel_size=2, stride=2))

		bsz, _, hgt, wdt = imgs1[0].shape
		flow = imgs1[0].new_zeros([bsz, 2, hgt, wdt])
		for lv in range(self.n_levels):
			if lv != 0:
				flow = 2 * bilinear_upscale(flow)
			flow = flow + self.module[lv](imgs1[lv], imgs2[lv], flow)
		return flow
