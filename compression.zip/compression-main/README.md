# compression

A utility library for data compression in PyTorch

## Installation

Clone this repo and run the following command:

```
cd compression
pip install -e .
```

Or download the released zip file and run:
```
pip install compression.zip
```
