
lambda=4096
model=elic2022
server=237
port=12355

#------------------------------------------------ train from scratch
export CUDA_VISIBLE_DEVICES="4"
python train.py \
-c ./cfgs/${model}-m${lambda}.yml \
-c ./cfgs/train_default_server${server}.yml \
--master_port ${port} \
--save_name ${model}-m${lambda} \
> ../logout/${model}-m${lambda}.log 2>&1 &

#------------------------------------------------ train from resume
# export CUDA_VISIBLE_DEVICES="2"
# python train.py \
# -c ./cfgs/${model}-m${lambda}.yml \
# -c ./cfgs/train_default_server2${server}.yml \
# --master_port ${port} \
# --save_name ${model}-m${lambda} \
# --ckpt_path /data/panxh/compression_baseline/compression/save/${model}-m128/latest.pth \
# >> ../logout/${model}-m${lambda}.log 2>&1 &


