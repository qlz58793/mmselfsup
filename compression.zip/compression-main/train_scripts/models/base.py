import shutil
import time
import glob
import math
import abc
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, List, Dict
from collections import defaultdict
from pathlib import Path
import copy
from functools import wraps

from data_compression.entropy_models import \
    ContinuousUnconditionalEntropyModel, ContinuousConditionalEntropyModel, \
    ContinuousEntropyModelBase
from data_compression.distributions.uniform_noised import \
    NoisyDeepFactorized, NoisyNormal
from data_compression.quantization import UniformQuantization
from data_compression.layers import MaskedConv2d, Downsample, Upsample
import data_compression.ops as ops
from data_compression.layers import GDN
import data_compression.utils as utils
from pytorch_msssim import ms_ssim
from data_compression.layers.compressai import AttentionBlock

Tensor = torch.Tensor


def mse_loss(x, x_hat):
    return ((x - x_hat) ** 2).mean()


def msssim_loss(x, x_hat, data_range=1.):
    return 1 - ms_ssim(x, x_hat, data_range=data_range)


def clamp(x, min=None, max=None):
    if min is not None:
        x = ops.lower_bound(x, min)
    if max is not None:
        x = ops.upper_bound(x, max)
    return x


def torch_use_deterministic_cudnn(func):
    @wraps(func)
    def _func(*args, **kwargs):
        is_deterministic = torch.backends.cudnn.deterministic
        torch.backends.cudnn.deterministic = True
        output = func(*args, **kwargs)
        torch.backends.cudnn.deterministic = is_deterministic
        return output
    return _func


class ImageCodingModelBase(nn.Module, metaclass=abc.ABCMeta):
    metric_table = ["mse", "ms-ssim"]

    def __init__(self, metric="mse"):
        super().__init__()
        # training metric
        self.metric = metric
        self.register_buffer("compression", torch.zeros(1, dtype=torch.bool))

    @property
    def metric_fn(self):
        assert self.metric in self.metric_table
        metric_fn = None
        if self.metric == "mse":
            metric_fn = mse_loss
        elif self.metric == "ms-ssim":
            metric_fn = msssim_loss
        return metric_fn

    @abc.abstractmethod
    def forward(self, x: Tensor, return_loss: bool):
        raise NotImplementedError

    @abc.abstractmethod
    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
		"""
        self.compression.fill_(True)

    @abc.abstractmethod
    def compress(self, x: Tensor) -> List[str]:
        """Compress `x` into byte strings.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def decompress(self, strings: List[str], wdt: int, hgt: int) -> Tensor:
        """Decompress `x` given byte strings
        """
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        raise NotImplementedError

    @property
    def device(self):
        return next(self.parameters()).device

    def pre_padding(self, x):
        hgt, wdt = x.shape[2:4]
        factor = self.downscale_factor
        dh = factor * math.ceil(hgt / factor) - hgt
        dw = factor * math.ceil(wdt / factor) - wdt
        x = F.pad(x, (dw//2, dw//2 + dw%2, dh//2, dh//2 + dh%2))
        return x

    def post_cropping(self, x, wdt, hgt):
        factor = self.downscale_factor
        dh = factor * math.ceil(hgt / factor) - hgt
        dw = factor * math.ceil(wdt / factor) - wdt
        return x[..., dh//2: -(dh//2 + dh%2) or None, \
                            dw//2: -(dw//2 + dw%2) or  None]

    @torch.no_grad()
    def evaluate(self, input_glob, output_dir=None, save_rec=False,
                 compression=False):
        input_ps = glob.glob(input_glob)

        if output_dir is not None:
            output_dir = Path(output_dir)
            shutil.rmtree(output_dir, ignore_errors=True)
            output_dir.mkdir(exist_ok=True, parents=True)

        logouts = []
        self.evaluate_one_file(input_ps[0])  # warmup
        for i, input_p in enumerate(input_ps):
            logouts.append(self.evaluate_one_file(
                input_p, output_dir, save_rec, compression))

        results =  defaultdict(float)
        for i in range(len(input_ps)):
            for k, v in logouts[i].items():
                results[k] += float(v) / len(input_ps)

        if output_dir is not None:
            json_results = {}
            json_results["num_files"] = len(input_ps)
            json_results.update(results)
            with open(output_dir / 'results.json', "w") as f:
                json.dump(json_results, f, indent=4)

        log_str = [f"num_files: {len(input_ps)}"]
        log_str += [f"{k}: {v:.6f}" for k, v in results.items()]
        log_str = ", ".join(log_str)
        return results["rd_loss"], log_str

    @torch.no_grad()
    def evaluate_one_file(self, input_p, output_dir=None, save_rec=False,
                          compression=False):
        device = self.device
        input_p = Path(input_p)

        ori = utils.load_file(input_p)
        assert ori.shape[0] == 1
        hgt, wdt = ori.shape[2:4]
        # inference
        ori = torch.from_numpy(ori).to(device)
        rec = ori.to(torch.float32).div(255.)
        rec = self.pre_padding(rec)

        torch.cuda.synchronize()
        t0 = time.time()
        if compression:
            strings = self.compress(rec)
            bits_list = [len(s) * 8 for s in strings]
            rec = self.decompress(strings, wdt, hgt)
        else:
            rec, bits_list = self.forward(rec, return_loss=False)
        torch.cuda.synchronize()
        t1 = time.time()

        rec = self.post_cropping(rec, wdt, hgt)
        rec = rec.clamp(0, 1).mul(255.).round().to(torch.uint8)

        # evaluation
        bits = sum(bits_list)
        bpp = bits / hgt / wdt
        rd_loss = self.rd_loss(
            ori,
            rec,
            bits,
            data_range=255.
        )
        psnr, msssim, _, _ = utils.measure_quality_torch(ori, rec)

        # save reconstruction
        if output_dir is not None and save_rec:
            rec = rec.cpu().numpy()
            suffix = ".png"
            file_stem = [
                input_p.stem,
                f"bpp{bpp:.4f}",
                f"psnr{psnr:.2f}",
                f"msssim{msssim:.4f}"
            ]
            file_stem = "_".join(file_stem)
            rec_name = file_stem + suffix
            rec_p = output_dir / rec_name
            rec_p.parent.mkdir(parents=True, exist_ok=True)
            utils.save_file(rec, rec_p)
        logout = {
            "rd_loss": rd_loss,
            "bpp": bpp,
            "psnr": psnr,
            "ms-ssim": msssim,
            "fw-time": t1 - t0
        }
        return logout