import shutil
import time
import glob
import math
import abc

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, List, Dict
from collections import defaultdict
from pathlib import Path
import copy
from functools import wraps

from data_compression.entropy_models import \
    ContinuousUnconditionalEntropyModel, ContinuousConditionalEntropyModel, \
    ContinuousEntropyModelBase
from data_compression.distributions.uniform_noised import \
    NoisyDeepFactorized, NoisyNormal
from data_compression.quantization import UniformQuantization
from data_compression.layers import MaskedConv2d, Downsample, Upsample
import data_compression.ops as ops
from data_compression.layers import GDN
import data_compression.utils as utils
from pytorch_msssim import ms_ssim
from data_compression.layers.compressai import AttentionBlock
from .base import ImageCodingModelBase

Tensor = torch.Tensor


def mse_loss(x, x_hat):
    return ((x - x_hat) ** 2).mean()


def msssim_loss(x, x_hat, data_range=1.):
    return 1 - ms_ssim(x, x_hat, data_range=data_range)


def clamp(x, min=None, max=None):
    if min is not None:
        x = ops.lower_bound(x, min)
    if max is not None:
        x = ops.upper_bound(x, max)
    return x


def torch_use_deterministic_cudnn(func):
    @wraps(func)
    def _func(*args, **kwargs):
        is_deterministic = torch.backends.cudnn.deterministic
        torch.backends.cudnn.deterministic = True
        output = func(*args, **kwargs)
        torch.backends.cudnn.deterministic = is_deterministic
        return output
    return _func


class ResidualBottleneckBlock(nn.Module):
    def __init__(self, C, ks=3):
        super().__init__()
        self.m = nn.Sequential(
            nn.Conv2d(C, C//2, 1, 1, 0),
            nn.ReLU(),
            nn.Conv2d(C//2, C//2, ks, 1, ks//2),
            nn.ReLU(),
            nn.Conv2d(C//2, C, 1, 1, 0),
        )
    def forward(self, x):
        return x + self.m(x)


class ELICHyperModel(ImageCodingModelBase):
    """
    """

    def __init__(self, N=192, M=320, lmbda=None, num_scales=64, scale_min=0.11,
                 scale_max=256, **kwargs):
        super().__init__(**kwargs)
        self.N = N
        self.M = M
        self.g_a = nn.Sequential(
            Downsample(3, N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            AttentionBlock(N),
            Downsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            Downsample(N, M),
            AttentionBlock(M)
        )
        self.g_s = nn.Sequential(
            AttentionBlock(M),
            Upsample(M, N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            Upsample(N, N),
            AttentionBlock(N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            Upsample(N, N),
            *[ResidualBottleneckBlock(N) for _ in range(3)],
            Upsample(N, 3)
        )
        self.h_a = nn.Sequential(
            nn.Conv2d(M, N, 3, 1, 1),
            nn.ReLU(),
            nn.Conv2d(N, N, 5, 2, 2),
            nn.ReLU(),
            nn.Conv2d(N, N, 5, 2, 2)
        )
        self.h_s = nn.Sequential(
            nn.ConvTranspose2d(N, M, 5, 2, 2, 1),
            nn.LeakyReLU(),
            nn.ConvTranspose2d(M, M * 3 // 2, 5, 2, 2, 1),
            nn.LeakyReLU(),
            nn.Conv2d(M * 3 // 2, M * 2, 3, 1, 1)
        )

        self.y_quant = UniformQuantization()
        self.z_quant = UniformQuantization()

        scale_table = self.build_scale_table(scale_min, scale_max, num_scales)
        self.scale_table = scale_table.tolist()
        self.y_em = ContinuousConditionalEntropyModel(
            NoisyNormal,
            param_tables=dict(loc=None, scale=self.scale_table)
        )
        self.z_em = ContinuousUnconditionalEntropyModel(
            NoisyDeepFactorized(batch_shape=(N,))
        )
        # dynamic training settings
        self.lmbda = lmbda

    def build_scale_table(self, min=0.11, max=256, steps=64):
        return torch.exp(torch.linspace(math.log(min), math.log(max), steps))

    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss

    def get_ready_for_compression(self):
        for m in self.modules():
            if isinstance(m, ContinuousEntropyModelBase):
                # m.get_ready_for_compression()
                m._fix_tables()
        super().get_ready_for_compression()

    def load_state_dict_custom(self, state_dict, strict=True):
        self.load_state_dict(state_dict, strict=False)
        if self.compression.all():
            for m in self.modules():
                if isinstance(m, ContinuousEntropyModelBase):
                    m._init_tables()
        else:
            self.get_ready_for_compression()
        self.load_state_dict(state_dict, strict=strict)

    def forward(self, x, return_loss=True):
        bits_list = []
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        bits = self.z_em(z_index)
        bits_list.append(bits)

        y_mean, y_scale = self.h_s(z_hat).chunk(2, 1)
        y_hat, _ = self.y_quant(y, offset=y_mean, noisy=False)
        _, y_index = self.y_quant(y, offset=y_mean, noisy=y.requires_grad)
        bits = self.y_em(
            y_index,
            loc=torch.zeros(1).to(x.device),
            scale=y_scale
        )
        bits_list.append(bits)

        x_hat = self.g_s(y_hat)

        if return_loss:
            return self.rd_loss(x, x_hat, sum(bits_list))
        else:
            return x_hat, bits_list

    @torch_use_deterministic_cudnn
    def compress(self, x, reconstruct=False):
        """Compresses an image tensor."""
        strings = []
        y = self.g_a(x)
        z = self.h_a(y)

        z_index = self.z_quant.quantize(z)
        string = self.z_em.compress(z_index)
        strings.append(string)
        z_hat = self.z_quant.dequantize(z_index)

        y_mean, y_scale = self.h_s(z_hat).chunk(2, 1)
        y_index = self.y_quant.quantize(y, offset=y_mean)
        string = self.y_em.compress(
            y_index,
            loc=torch.zeros(1).to(x.device),
            scale=y_scale
        )
        strings.append(string)

        if reconstruct:
            y_hat = self.y_quant.dequantize(y_index, offset=y_mean)
            x_hat = self.g_s(y_hat)
            return strings, x_hat
        else:
            return strings

    @torch_use_deterministic_cudnn
    def decompress(self, strings, wdt, hgt):
        """Decompresses an image tensor."""
        factor = self.downscale_factor
        z_shape = [int(math.ceil(s / factor)) for s in [hgt, wdt]]
        z_index = self.z_em.decompress(strings.pop(0), z_shape)
        z_hat = self.z_quant.dequantize(z_index)

        y_mean, y_scale = self.h_s(z_hat).chunk(2, 1)
        y_index = self.y_em.decompress(
            strings.pop(0),
            loc=torch.zeros(1).to(z_hat.device),
            scale=y_scale
        )
        y_hat = self.y_quant.dequantize(y_index, offset=y_mean)
        x_hat = self.g_s(y_hat)
        return x_hat

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)



class ELICModel(ELICHyperModel):
    """
    """

    def __init__(self, N=192, M=320, slice_depths=(16, 16, 32, 64, 192),
                 **kwargs):
        super().__init__(N=N, M=M, **kwargs)
        assert M == sum(slice_depths)
        self.slice_depths = slice_depths
        self.g_sp = nn.ModuleList()
        self.g_ch_mean = nn.ModuleList()
        self.g_ch_scale = nn.ModuleList()
        self.param_aggregation = nn.ModuleList()
        for k, Mk in enumerate(slice_depths):
            g_sp = nn.Conv2d(Mk, 2*Mk, 5, 1, 2)
            if k == 0:
                g_ch_mean = nn.Sequential()
                g_ch_scale = nn.Sequential()
            else:
                conv_depths = torch.linspace(sum(slice_depths[:k]), Mk, 4)
                conv_depths = conv_depths.round().int().numpy()
                g_ch_mean = nn.Sequential(
                    nn.Conv2d(conv_depths[0], conv_depths[1], 3, 1, 1),
                    nn.ReLU(),
                    nn.Conv2d(conv_depths[1], conv_depths[2], 3, 1, 1),
                    nn.ReLU(),
                    nn.Conv2d(conv_depths[2], conv_depths[3], 3, 1, 1),
                )
                g_ch_scale = copy.deepcopy(g_ch_mean)
            conv_depths = torch.linspace(Mk*4 + M*2, Mk*2, 4)
            conv_depths = conv_depths.round().int().numpy()
            param_aggregation = nn.Sequential(
                nn.Conv2d(conv_depths[0], conv_depths[1], 1, 1, 0),
                nn.ReLU(),
                nn.Conv2d(conv_depths[1], conv_depths[2], 1, 1, 0),
                nn.ReLU(),
                nn.Conv2d(conv_depths[2], conv_depths[3], 1, 1, 0)
            )
            self.g_sp.append(g_sp)
            self.g_ch_mean.append(g_ch_mean)
            self.g_ch_scale.append(g_ch_scale)
            self.param_aggregation.append(param_aggregation)

        self.y_em = ContinuousConditionalEntropyModel(
            NoisyNormal,
            param_tables=dict(loc=None, scale=self.scale_table)
        )
        self.z_em = ContinuousUnconditionalEntropyModel(
            NoisyDeepFactorized(batch_shape=(N,))
        )

    def build_scale_table(self, min=0.11, max=256, steps=64):
        return torch.exp(torch.linspace(math.log(min), math.log(max), steps))

    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss

    def checkboard_split(self, x, mode="a"):
        bcs, dpt, hgt, wdt = x.shape
        x = x.reshape(bcs * dpt, 1, hgt, wdt)
        x = F.pixel_unshuffle(x, downscale_factor=2)
        if mode == "a":
            x_a = [x[:, 0:1, :, :], x[:, 3:4, :, :]]
            x_a = torch.cat(x_a, dim=1)
            x_a = x_a.reshape(bcs, dpt, hgt, wdt // 2)
            return x_a
        if mode == "b":
            x_b = x[:, 1:3, :, :]
            x_b = x_b.reshape(bcs, dpt, hgt, wdt // 2)
            return x_b
        if mode == "ab":
            x_a = [x[:, 0:1, :, :], x[:, 3:4, :, :]]
            x_a = torch.cat(x_a, dim=1)
            x_a = x_a.reshape(bcs, dpt, hgt, wdt // 2)
            x_b = x[:, 1:3, :, :]
            x_b = x_b.reshape(bcs, dpt, hgt, wdt // 2)
            return x_a, x_b
        assert mode in ["a", "b", "ab"]

    def checkboard_merge(self, x_a, x_b):
        assert x_a.shape == x_b.shape
        bcs, dpt, hgt, wdt_half = x_a.shape
        x_a = x_a.reshape(bcs * dpt, 2, hgt // 2, wdt_half)
        x_b = x_b.reshape(bcs * dpt, 2, hgt // 2, wdt_half)
        x = torch.cat([
            x_a[:, 0:1, :, :],
            x_b[:, 0:1, :, :],
            x_b[:, 1:2, :, :],
            x_a[:, 1:2, :, :]
        ], dim=1)
        x = F.pixel_shuffle(x, upscale_factor=2)
        x = x.reshape(bcs, dpt, hgt, wdt_half * 2)
        return x

    def forward(self, x, return_loss=True):
        bits_list = []
        y = self.g_a(x)
        z = self.h_a(y)
        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        bits = self.z_em(z_index)
        bits_list.append(bits)
        y_hyper = self.h_s(z_hat)

        n_slices = len(self.g_ch_mean)
        y_slices = y.split(self.slice_depths, dim=1)
        y_slices_hat = []
        for k in range(n_slices):
            sli = y_slices[k]
            Mk = self.slice_depths[k]
            g_sp = self.g_sp[k]
            g_ch_mean = self.g_ch_mean[k]
            g_ch_scale = self.g_ch_scale[k]
            param_aggregation = self.param_aggregation[k]

            # channel
            if k == 0:
                ch_ctx_shape = [y_hyper.shape[0], 2*Mk, *y_hyper.shape[-2:]]
                ch_ctx = y_hyper.new_zeros(*ch_ctx_shape)
            else:
                y_hat = torch.cat(y_slices_hat, dim=1)
                ch_ctx = [g_ch_mean(y_hat), g_ch_scale(y_hat)]
                ch_ctx = torch.cat(ch_ctx, dim=1)

            # spatial: a part & b part
            sli_a, sli_b = self.checkboard_split(sli, mode="ab")

            sp_ctx = torch.zeros_like(ch_ctx)
            param_a = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_a = self.checkboard_split(param_a, mode="a")
            mean_a, scale_a = param_a.chunk(2, dim=1)
            _, sli_index_a = self.y_quant(
                sli_a, offset=mean_a, noisy=sli_a.requires_grad)
            bits = self.y_em(
                sli_index_a,
                loc=x.new_zeros([1]),
                scale=scale_a
            )
            bits_list.append(bits)
            sli_hat_a, _ = self.y_quant(sli_a, offset=mean_a, noisy=False)

            sli_hat_b = torch.zeros_like(sli_hat_a)
            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            sp_ctx = g_sp(sli_hat)
            param_b = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_b = self.checkboard_split(param_b, mode="b")
            mean_b, scale_b = param_b.chunk(2, dim=1)
            _, sli_index_b = self.y_quant(
                sli_b, offset=mean_b, noisy=sli_b.requires_grad)
            bits = self.y_em(
                sli_index_b,
                loc=x.new_zeros([1]),
                scale=scale_b
            )
            bits_list.append(bits)
            sli_hat_b, _ = self.y_quant(sli_b, offset=mean_b, noisy=False)

            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            y_slices_hat.append(sli_hat)

        y_hat = torch.cat(y_slices_hat, dim=1)
        x_hat = self.g_s(y_hat)

        if return_loss:
            return self.rd_loss(x, x_hat, sum(bits_list))
        else:
            return x_hat, bits_list

    @torch_use_deterministic_cudnn
    def compress(self, x, reconstruct=False):
        """Compresses an image tensor."""
        strings = []
        y = self.g_a(x)
        z = self.h_a(y)
        z_index = self.z_quant.quantize(z)
        string = self.z_em.compress(z_index)
        strings.append(string)
        z_hat = self.z_quant.dequantize(z_index)
        y_hyper = self.h_s(z_hat)

        n_slices = len(self.g_ch_mean)
        y_slices = y.split(self.slice_depths, dim=1)
        y_slices_hat = []
        for k in range(n_slices):
            sli = y_slices[k]
            Mk = self.slice_depths[k]
            g_sp = self.g_sp[k]
            g_ch_mean = self.g_ch_mean[k]
            g_ch_scale = self.g_ch_scale[k]
            param_aggregation = self.param_aggregation[k]

            # channel
            if k == 0:
                ch_ctx_shape = [y_hyper.shape[0], 2*Mk, *y_hyper.shape[-2:]]
                ch_ctx = y_hyper.new_zeros(*ch_ctx_shape)
            else:
                y_hat = torch.cat(y_slices_hat, dim=1)
                ch_ctx = [g_ch_mean(y_hat), g_ch_scale(y_hat)]
                ch_ctx = torch.cat(ch_ctx, dim=1)

            # spatial: a part & b part
            sli_a, sli_b = self.checkboard_split(sli, mode="ab")

            sp_ctx = torch.zeros_like(ch_ctx)
            param_a = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_a = self.checkboard_split(param_a, mode="a")
            mean_a, scale_a = param_a.chunk(2, dim=1)
            sli_index_a = self.y_quant.quantize(sli_a, offset=mean_a)
            string = self.y_em.compress(
                sli_index_a,
                loc=x.new_zeros([1]),
                scale=scale_a
            )
            strings.append(string)
            sli_hat_a = self.y_quant.dequantize(sli_index_a, offset=mean_a)

            sli_hat_b = torch.zeros_like(sli_hat_a)
            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            sp_ctx = g_sp(sli_hat)
            param_b = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_b = self.checkboard_split(param_b, mode="b")
            mean_b, scale_b = param_b.chunk(2, dim=1)
            sli_index_b = self.y_quant.quantize(sli_b, offset=mean_b)
            string = self.y_em.compress(
                sli_index_b,
                loc=x.new_zeros([1]),
                scale=scale_b
            )
            strings.append(string)
            sli_hat_b = self.y_quant.dequantize(sli_index_b, offset=mean_b)

            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            y_slices_hat.append(sli_hat)
            # alpha_param = param.new_empty(*param.shape[:2], hgt, wdt//2)
            # alpha_param[:, :, 0::2, :] = param[:, :, 0::2, 0::2]
            # alpha_param[:, :, 1::2, :] = param[:, :, 1::2, 1::2]
            #
            # alpha = y_sli.new_empty(*y_sli.shape[:2], hgt, wdt // 2)
            # alpha[:, :, 0::2, :] = y_sli[:, :, 0::2, 0::2]
            # alpha[:, :, 1::2, :] = y_sli[:, :, 1::2, 1::2]
        # self.y_slices_hat = y_slices_hat
        if reconstruct:
            y_hat = torch.cat(y_slices_hat, dim=1)
            x_hat = self.g_s(y_hat)
            return strings, x_hat
        else:
            return strings

    @torch_use_deterministic_cudnn
    def decompress(self, strings, wdt, hgt):
        """Decompresses an image tensor."""
        factor = self.downscale_factor
        z_shape = [int(math.ceil(s / factor)) for s in [hgt, wdt]]
        z_index = self.z_em.decompress(strings.pop(0), z_shape)
        z_hat = self.z_quant.dequantize(z_index)
        y_hyper = self.h_s(z_hat)

        n_slices = len(self.g_ch_mean)
        y_slices_hat = []
        for k in range(n_slices):
            Mk = self.slice_depths[k]
            g_sp = self.g_sp[k]
            g_ch_mean = self.g_ch_mean[k]
            g_ch_scale = self.g_ch_scale[k]
            param_aggregation = self.param_aggregation[k]

            # channel
            if k == 0:
                ch_ctx_shape = [y_hyper.shape[0], 2*Mk, *y_hyper.shape[-2:]]
                ch_ctx = y_hyper.new_zeros(*ch_ctx_shape)
            else:
                y_hat = torch.cat(y_slices_hat, dim=1)
                ch_ctx = [g_ch_mean(y_hat), g_ch_scale(y_hat)]
                ch_ctx = torch.cat(ch_ctx, dim=1)

            # spatial: a part & b part
            sp_ctx = torch.zeros_like(ch_ctx)
            param_a = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_a = self.checkboard_split(param_a, mode="a")
            mean_a, scale_a = param_a.chunk(2, dim=1)

            sli_index_a = self.y_em.decompress(
                strings.pop(0),
                loc=y_hyper.new_zeros([1]),
                scale=scale_a
            )
            sli_hat_a = self.y_quant.dequantize(sli_index_a, offset=mean_a)

            sli_hat_b = torch.zeros_like(sli_hat_a)
            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            sp_ctx = g_sp(sli_hat)
            param_b = param_aggregation(
                torch.cat([sp_ctx, ch_ctx, y_hyper], dim=1)
            )
            param_b = self.checkboard_split(param_b, mode="b")
            mean_b, scale_b = param_b.chunk(2, dim=1)
            sli_index_b = self.y_em.decompress(
                strings.pop(0),
                loc=y_hyper.new_zeros([1]),
                scale=scale_b
            )
            sli_hat_b = self.y_quant.dequantize(sli_index_b, offset=mean_b)

            sli_hat = self.checkboard_merge(sli_hat_a, sli_hat_b)
            y_slices_hat.append(sli_hat)
            # assert sli_hat.equal(self.y_slices_hat[k])

        y_hat = torch.cat(y_slices_hat, dim=1)
        x_hat = self.g_s(y_hat)
        return x_hat