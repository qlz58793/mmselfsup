import shutil
import time
import glob
import math
import sys
import os
import abc
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, List, Dict
from collections import defaultdict
from pathlib import Path

from data_compression.entropy_models import \
    ContinuousUnconditionalEntropyModel, ContinuousConditionalEntropyModel
from data_compression.distributions.uniform_noised import \
    NoisyDeepFactorized, NoisyNormal
from data_compression.quantization import UniformQuantization
from data_compression.layers import \
    MaskedConv2d, ResBlocks, Downsample, Upsample
import data_compression.ops as ops
from data_compression.layers import GDN
import data_compression.utils as utils
from pytorch_msssim import ms_ssim

from train_scripts.models import \
    ImageCodingModelBase, BMSHJ2018Model, Cheng2020Model
# from train_scripts_video.models.intra import ELICModel, ELICHyperModel


def mse_loss(x, x_hat):
    return ((x - x_hat) ** 2).mean()


def msssim_loss(x, x_hat, data_range=1.):
    return 1 - ms_ssim(x, x_hat, data_range=data_range)


def clamp(x, min=None, max=None):
    if min is not None:
        x = ops.lower_bound(x, min)
    if max is not None:
        x = ops.upper_bound(x, max)
    return x


class TransformImageCoding(ImageCodingModelBase):
    """
    """

    def __init__(self, transform_channels, hyper_channels, quant_type, 
                 lmbda=None, num_scales=64, scale_min=0.11, scale_max=256, 
                 **kwargs):
        super().__init__(**kwargs)
        in_channel = 3
        out_channel = 3
        self.quant_type = quant_type
        self.transform_channels = transform_channels
        self.hyper_channels = hyper_channels
        m = []
        for i in range(len(self.transform_channels)):
            Ci = self.transform_channels[i]
            if i == 0:
                m.append(Downsample(in_channel, Ci))
            else:
                Cim1 = self.transform_channels[i-1]
                m.append(ResBlocks(Cim1))
                m.append(Downsample(Cim1, Ci))
        self.g_a = nn.Sequential(*m)

        m = []
        for i in range(len(self.transform_channels))[::-1]:
            Ci = self.transform_channels[i]
            if i == 0:
                m.append(Upsample(Ci, out_channel))
            else:
                Cim1 = self.transform_channels[i-1]
                m.append(Upsample(Ci, Cim1))
                m.append(ResBlocks(Cim1))
        self.g_s = nn.Sequential(*m)

        self.y_quant = UniformQuantization()
        self.z_quant = UniformQuantization()

        ## init hyper
        y_channel = self.transform_channels[-1]
        if self.hyper_channels is None:
            self.y_em = ContinuousUnconditionalEntropyModel(
                NoisyDeepFactorized(batch_shape=(y_channel,)))
        else:
            m = []
            for i in range(len(self.hyper_channels)):
                Ci = self.hyper_channels[i]
                if i == 0:
                    m.append(nn.Conv2d(y_channel, Ci, 3, 1, 1))
                else:
                    Cim1 = self.hyper_channels[i - 1]
                    m.append(nn.ReLU())
                    m.append(nn.Conv2d(Cim1, Ci, 5, 2, 2))
            self.h_a = nn.Sequential(*m)

            m = []
            for i in range(len(self.hyper_channels))[::-1]:
                Ci = self.hyper_channels[i]
                if i == 0:
                    m.append(nn.Conv2d(Ci, y_channel * 2, 3, 1, 1))
                else:
                    Cim1 = self.hyper_channels[i - 1]
                    m.append(nn.ConvTranspose2d(Ci, Cim1, 5, 2, 2, 1))
                    m.append(nn.ReLU())
            self.h_s = nn.Sequential(*m)

            scale_table = self.build_scale_table(
                scale_min, scale_max, num_scales
            )
            self.scale_table = scale_table.tolist()
            self.y_em = ContinuousConditionalEntropyModel(
                NoisyNormal, 
                param_tables=dict(loc=[0], scale=self.scale_table)
            )
            self.z_em = ContinuousUnconditionalEntropyModel(
                NoisyDeepFactorized(batch_shape=(self.hyper_channels[-1],))
            )
        # dynamic training settings
        self.lmbda = lmbda

    def build_scale_table(self, min, max, steps):
        return torch.exp(torch.linspace(math.log(min), math.log(max), steps))
    
    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss
    
    def forward(self, x, return_loss=True):
        y = self.g_a(x)

        if not hasattr(self, 'z_em'):
            _, y_indexes = self.y_quant(y, noisy=y.requires_grad)
            y_hat, _ = self.y_quant(
                y, 
                noisy=y.requires_grad if self.quant_type == 'noisy' else False
            )
            y_bits = self.y_em(y_indexes)
            z_bits = torch.zeros_like(y_bits)
        else:
            z = self.h_a(y)
            z_hat, z_indexes = self.z_quant(z, noisy=z.requires_grad)
            y_means, y_scales = self.h_s(z_hat).chunk(2, 1)
            _, y_indexes = self.y_quant(
                y, offset=y_means, noisy=y.requires_grad
            )
            y_hat, _ = self.y_quant(
                y, 
                offset=y_means, 
                noisy=y.requires_grad if self.quant_type == 'noisy' else False
            )
            y_bits = self.y_em(
                y_indexes, 
                loc=torch.zeros(1).to(x.device), 
                scale=y_scales
            )
            z_bits = self.z_em(z_indexes)
        x_hat = self.g_s(y_hat)
        
        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]

    def init_tables(self):
        for m in self.modules():
            if hasattr(m, '_init_tables'):
                m._init_tables()

    def fix_tables(self):
        for m in self.modules():
            if hasattr(m, '_fix_tables'):
                m._fix_tables()

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass
    
    def compress(self, x, reconstruct=False):
        """Compresses an image tensor."""
        y = self.g_a(x)
        if not hasattr(self, 'z_em'):
            y_indexes = self.y_quant.quantize(y)
            string = self.y_em.compress(y_indexes)
            side_string = ''
        else:
            z = self.h_a(y)
            z_hat, z_indexes = self.z_quant(z, noisy=False)
            y_means, y_scales = self.h_s(z_hat).chunk(2, 1)
            y_indexes = self.y_quant.quantize(y, offset=y_means)
            y_loc = torch.zeros(1).to(x.device)
            string = self.y_em.compress(y_indexes, loc=y_loc, scale=y_scales)
            side_string = self.z_em.compress(z_indexes)
        strings = [string, side_string]
        if reconstruct:
            if not hasattr(self, 'z_em'):
                y_means = None
            y_hat = self.y_quant.dequantize(y_indexes, offset=y_means)
            x_hat = self.g_s(y_hat)
            return strings, x_hat
        else:
            return strings

    def decompress(self, strings, shape):
        """Decompresses an image tensor."""
        string, side_string = strings
        factor = 64
        if not hasattr(self, 'z_em'):
            y_shape = [int(math.ceil(s / factor)) * 16 for s in shape]
            y_indexes = self.y_em.decompress(string, y_shape)
            y_hat = self.y_quant.dequantize(y_indexes)
        else:
            z_shape = [int(math.ceil(s / factor)) for s in shape]
            z_indexes = self.z_em.decompress(side_string, z_shape)
            z_hat = self.z_quant.dequantize(z_indexes)
            y_means, y_scales = self.h_s(z_hat).chunk(2, 1)
            y_loc = torch.zeros(1).to(z_hat.device)
            y_indexes = self.y_em.decompress(string, loc=y_loc, scale=y_scales)
            y_hat = self.y_quant.dequantize(y_indexes, offset=y_means)
        x_hat = self.g_s(y_hat)
        return x_hat
    
    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


class RDTHyper(TransformImageCoding):
    # For our w/o maskconv baseline, noise training, add entropy parameters
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        y_channel = self.transform_channels[-1]
        self.g_ctx = nn.Sequential(
            nn.Conv2d(y_channel * 3, y_channel * 2, 3, 1, 1),
            nn.LeakyReLU(),
            nn.Conv2d(y_channel * 2, y_channel * 2, 3, 1, 1),
            nn.LeakyReLU(),
            nn.Conv2d(y_channel * 2, y_channel * 2, 3, 1, 1),
        )

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)
        
        z_hat, z_indexes = self.z_quant(z, noisy=z.requires_grad)
        y_hyper = self.h_s(z_hat)
        y_context = torch.cat((y_hyper, torch.zeros_like(y)), dim=1)
        y_means, y_scales = self.g_ctx(y_context).chunk(2, 1)
        _, y_indexes = self.y_quant(
            y, offset=y_means, noisy=y.requires_grad
        )
        y_hat, _ = self.y_quant(
            y, 
            offset=y_means, 
            noisy=y.requires_grad if self.quant_type == 'noisy' else False
        )
        y_bits = self.y_em(
            y_indexes, 
            loc=torch.zeros(1).to(x.device), 
            scale=y_scales
        )
        z_bits = self.z_em(z_indexes)
        x_hat = self.g_s(y_hat)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass
    
    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, shape):
        """Decompress an image `x` given byte strings
        """
        pass
    
    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


class BMSHJ2018ModelMixQuant(BMSHJ2018Model):
    """
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        y_scale = self.h_s(z_hat)
        _, y_index = self.y_quant(y, noisy=y.requires_grad)
        y_hat, _ = self.y_quant(y, noisy=False)
        x_hat = self.g_s(y_hat)

        y_bits = self.y_em(
            y_index,
            loc=torch.zeros(1).to(x.device),
            scale=y_scale
        )
        z_bits = self.z_em(z_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]


class Cheng2020ModelMixQuant(Cheng2020Model):
    """
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        y_hyper = self.h_s(z_hat)
        _, y_index = self.y_quant(y, noisy=y.requires_grad)
        y_hat, _ = self.y_quant(y, noisy=False)
        y_ctx = self.context_model(y_hat)
        y_ctx = torch.cat([y_hyper, y_ctx], dim=1)
        y_mean, y_scale = self.entropy_parameters(y_ctx).chunk(2, 1)
        x_hat = self.g_s(y_hat)

        y_bits = self.y_em(
            y_index,
            loc=y_mean,
            scale=y_scale
        )
        z_bits = self.z_em(z_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]


# class ELIC2022Model(ELICModel):
#     """
#     """
#     def __init__(self, **kwargs):
#         super().__init__(**kwargs)
#
#