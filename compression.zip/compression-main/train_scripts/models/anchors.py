import shutil
import time
import glob
import math
import abc
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, List, Dict
from collections import defaultdict
from pathlib import Path

from data_compression.entropy_models import \
    ContinuousUnconditionalEntropyModel, ContinuousConditionalEntropyModel
from data_compression.distributions.uniform_noised import \
    NoisyDeepFactorized, NoisyNormal
from data_compression.quantization import UniformQuantization
from data_compression.layers import MaskedConv2d
import data_compression.ops as ops
from data_compression.layers import GDN
import data_compression.utils as utils
from pytorch_msssim import ms_ssim

from data_compression.layers.compressai import (
    AttentionBlock,
    ResidualBlock,
    ResidualBlockUpsample,
    ResidualBlockWithStride,
    conv3x3,
    subpel_conv3x3,
)
Tensor = torch.Tensor
from .base import ImageCodingModelBase


def mse_loss(x, x_hat):
    return ((x - x_hat) ** 2).mean()


def msssim_loss(x, x_hat, data_range=1.):
    return 1 - ms_ssim(x, x_hat, data_range=data_range)


def clamp(x, min=None, max=None):
    if min is not None:
        x = ops.lower_bound(x, min)
    if max is not None:
        x = ops.upper_bound(x, max)
    return x


# class ImageCodingModelBase(nn.Module, metaclass=abc.ABCMeta):
#     metric_table = ["mse", "ms-ssim"]
#
#     def __init__(self, metric="mse"):
#         super().__init__()
#         # training metric
#         self.metric = metric
#
#     @property
#     def metric_fn(self):
#         assert self.metric in self.metric_table
#         metric_fn = None
#         if self.metric == "mse":
#             metric_fn = mse_loss
#         elif self.metric == "ms-ssim":
#             metric_fn = msssim_loss
#         return metric_fn
#
#     @abc.abstractmethod
#     def forward(self, x: Tensor, return_loss: bool):
#         raise NotImplementedError
#
#     @abc.abstractmethod
#     def get_ready_for_compression(self):
#         """Get everything ready before separating the encoder and decoder.
# 		"""
#         raise NotImplementedError
#
#     @abc.abstractmethod
#     def compress(self, x: Tensor) -> List[str]:
#         """Compress `x` into byte strings.
#         """
#         raise NotImplementedError
#
#     @abc.abstractmethod
#     def decompress(self, strings: List[str], wdt: int, hgt: int) -> Tensor:
#         """Decompress `x` given byte strings
#         """
#         raise NotImplementedError
#
#     @property
#     @abc.abstractmethod
#     def downscale_factor(self):
#         """ Maximum down-scale factor
#         """
#         raise NotImplementedError
#
#     def pre_padding(self, x):
#         hgt, wdt = x.shape[2:4]
#         factor = self.downscale_factor
#         dh = factor * math.ceil(hgt / factor) - hgt
#         dw = factor * math.ceil(wdt / factor) - wdt
#         x = F.pad(x, (dw//2, dw//2 + dw%2, dh//2, dh//2 + dh%2))
#         return x
#
#     def post_cropping(self, x, wdt, hgt):
#         factor = self.downscale_factor
#         dh = factor * math.ceil(hgt / factor) - hgt
#         dw = factor * math.ceil(wdt / factor) - wdt
#         return x[..., dh//2: -(dh//2 + dh%2) or None, \
#                             dw//2: -(dw//2 + dw%2) or  None]
#
#     @torch.no_grad()
#     def evaluate(self, file_glob, output_dir=None):
#
#         file_ps = glob.glob(file_glob)
#         logouts = []
#         self.evaluate_one_file(file_ps[0]) # warmup
#         if output_dir is not None:
#             shutil.rmtree(output_dir, ignore_errors=True)
#         for i, file_p in enumerate(file_ps):
#             logouts.append(self.evaluate_one_file(file_p, output_dir))
#
#         results =  defaultdict(float)
#         for i in range(len(file_ps)):
#             for k, v in logouts[i].items():
#                 results[k] += v / len(file_ps)
#
#         log_str = [f"num_files: {len(file_ps)}"]
#         log_str += [f"{k}: {v:.6f}" for k, v in results.items()]
#         log_str = ", ".join(log_str)
#         return results["rd_loss"], log_str
#
#     @torch.no_grad()
#     def evaluate_one_file(self, file_p, rec_dir=None):
#         device = next(self.parameters()).device
#         file_p = Path(file_p)
#         ori = utils.load_file(file_p)
#         assert ori.shape[0] == 1
#         hgt, wdt = ori.shape[2:4]
#         # inference
#         ori = torch.from_numpy(ori).to(device)
#         rec = ori.to(torch.float32).div(255.)
#         rec = self.pre_padding(rec)
#         torch.cuda.synchronize()
#         t0 = time.time()
#         rec, bits_list = self.forward(rec, return_loss=False)
#         torch.cuda.synchronize()
#         t1 = time.time()
#         rec = self.post_cropping(rec, wdt, hgt)
#         rec = rec.clamp(0, 1).mul(255.).round().to(torch.uint8)
#
#         # evaluation
#         bits = sum(bits_list)
#         bpp = bits / hgt / wdt
#         rd_loss = self.rd_loss(
#             ori,
#             rec,
#             bits,
#             data_range=255.
#         )
#         psnr, msssim, _, _ = utils.measure_quality_torch(ori, rec)
#         # save reconstruction
#         if rec_dir is not None:
#             rec = rec.cpu().numpy()
#             suffix = ".png"
#             file_stem = [
#                 file_p.stem,
#                 f"bpp{bpp:.4f}",
#                 f"psnr{psnr:.2f}",
#                 f"msssim{msssim:.4f}"
#             ]
#             file_stem = "_".join(file_stem)
#             rec_name = file_stem + suffix
#             rec_p = rec_dir / rec_name
#             rec_p.parent.mkdir(parents=True, exist_ok=True)
#             utils.save_file(rec, rec_p)
#         logout = {
#             "rd_loss": rd_loss,
#             "bpp": bpp,
#             "psnr": psnr,
#             "ms-ssim": msssim,
#             "fw-time": t1 - t0
#         }
#         return logout


class BLS2017Model(ImageCodingModelBase):
    """
    J. Ballé, V. Laparra, E.P. Simoncelli (2017):
    "End-to-end Optimized Image Compression"
    Int. Conf. on Learning Representations (ICLR), 2017
    https://arxiv.org/abs/1611.01704
    """

    def __init__(self, N, M, lmbda=None, **kwargs):
        super().__init__(**kwargs)
        self.N = N
        self.M = M
        self.g_a = nn.Sequential(
            nn.Conv2d(3, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, M, 5, 2, 2)
        )
        self.g_s = nn.Sequential(
            nn.ConvTranspose2d(M, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, 3, 5, 2, 2, 1)
        )
        self.y_quant = UniformQuantization()
        self.y_em = ContinuousUnconditionalEntropyModel(
            NoisyDeepFactorized(batch_shape=(M,))
        )
        # dynamic training settings
        self.lmbda = lmbda

    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss
        
    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        y_hat, y_index = self.y_quant(y, noisy=y.requires_grad)
        x_hat = self.g_s(y_hat)
        y_bits = self.y_em(y_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits)
        else:
            return x_hat, [y_bits]

    def get_ready_for_compression(self):
        """Get everything ready for compressing and decompressing.
        """
        pass

    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, wdt, hgt):
        """Decompress an image `x` given byte strings
        """
        pass

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** 4



class BMSHJ2018Model(ImageCodingModelBase):
    """
    J. Ballé, D. Minnen, S. Singh, S.J. Hwang, N. Johnston:
    "Variational Image Compression with a Scale Hyperprior"
    Int. Conf. on Learning Representations (ICLR), 2018
    https://arxiv.org/abs/1802.01436
    """

    def __init__(self, N=128, M=192, lmbda=None, num_scales=64, scale_min=0.11,
                 scale_max=256, **kwargs):
        super().__init__(**kwargs)
        self.N = N
        self.M = M
        self.g_a = nn.Sequential(
            nn.Conv2d(3, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, N, 5, 2, 2),
            GDN(N),
            nn.Conv2d(N, M, 5, 2, 2)
        )
        self.g_s = nn.Sequential(
            nn.ConvTranspose2d(M, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            GDN(N, inverse=True),
            nn.ConvTranspose2d(N, 3, 5, 2, 2, 1)
        )
        self.h_a = nn.Sequential(
            nn.Conv2d(M, N, 3, 1, 1),
            nn.ReLU(),
            nn.Conv2d(N, N, 5, 2, 2),
            nn.ReLU(),
            nn.Conv2d(N, N, 5, 2, 2)
        )
        self.h_s = nn.Sequential(
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            nn.ReLU(),
            nn.ConvTranspose2d(N, N, 5, 2, 2, 1),
            nn.ReLU(),
            nn.Conv2d(N, M, 3, 1, 1)
        )

        self.y_quant = UniformQuantization()
        self.z_quant = UniformQuantization()

        scale_table = self.build_scale_table(scale_min, scale_max, num_scales)
        self.scale_table = scale_table.tolist()
        self.y_em = ContinuousConditionalEntropyModel(
            NoisyNormal,
            param_tables=dict(loc=None, scale=self.scale_table)
        )
        self.z_em = ContinuousUnconditionalEntropyModel(
            NoisyDeepFactorized(batch_shape=(N,))
        )
        # dynamic training settings
        self.lmbda = lmbda

    def build_scale_table(self, min=0.11, max=256, steps=64):
        return torch.exp(torch.linspace(math.log(min), math.log(max), steps))

    def rd_loss(self, ori, rec, bits, data_range=1.):
        assert self.lmbda is not None
        ori = ori.float() / data_range
        rec = rec.float() / data_range
        r_loss = bits / ori.numel()
        d_loss = self.lmbda * self.metric_fn(ori, rec)
        return r_loss + d_loss

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        y_scale = self.h_s(z_hat)
        y_hat, y_index = self.y_quant(y, noisy=y.requires_grad)
        x_hat = self.g_s(y_hat)

        y_bits = self.y_em(
            y_index,
            loc=torch.zeros(1).to(x.device),
            scale=y_scale
        )
        z_bits = self.z_em(z_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass

    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, shape):
        """Decompress an image `x` given byte strings
        """
        pass

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


class MBT2018MeanScaleOnlyModel(BMSHJ2018Model):
    """

    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        N = self.N
        M = self.M
        self.h_s = nn.Sequential(
            nn.ConvTranspose2d(N, M, 5, 2, 2, 1),
            nn.LeakyReLU(),
            nn.ConvTranspose2d(M, M * 3 // 2, 5, 2, 2, 1),
            nn.LeakyReLU(),
            nn.Conv2d(M * 3 // 2, M * 2, 3, 1, 1)
        )

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        y_mean, y_scale = self.h_s(z_hat).chunk(2, 1)
        y_hat, y_index = self.y_quant(y, offset=y_mean, noisy=y.requires_grad)
        x_hat = self.g_s(y_hat)

        y_bits = self.y_em(
            y_index,
            loc=torch.zeros(1).to(x.device),
            scale=y_scale
        )
        z_bits = self.z_em(z_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass

    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, shape):
        """Decompress an image `x` given byte strings
        """
        pass

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


class MBT2018Model(MBT2018MeanScaleOnlyModel):
    """
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        M = self.M
        self.entropy_parameters = nn.Sequential(
            nn.Conv2d(M * 12 // 3, M * 10 // 3, 1),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(M * 10 // 3, M * 8 // 3, 1),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(M * 8 // 3, M * 6 // 3, 1),
        )
        self.context_model = MaskedConv2d(M, 2 * M, 5, 1, 2)

    def forward(self, x, return_loss=True):
        y = self.g_a(x)
        z = self.h_a(y)

        z_hat, z_index = self.z_quant(z, noisy=z.requires_grad)
        y_hyper = self.h_s(z_hat)
        y_hat, y_index = self.y_quant(y, noisy=y.requires_grad)
        y_ctx = self.context_model(y_hat)
        y_ctx = torch.cat([y_hyper, y_ctx], dim=1)
        y_mean, y_scale = self.entropy_parameters(y_ctx).chunk(2, 1)
        x_hat = self.g_s(y_hat)

        y_bits = self.y_em(
            y_index,
            loc=y_mean,
            scale=y_scale
        )
        z_bits = self.z_em(z_index)

        if return_loss:
            return self.rd_loss(x, x_hat, y_bits + z_bits)
        else:
            return x_hat, [y_bits, z_bits]

    def get_ready_for_compression(self):
        """Get everything ready before separating the encoder and decoder.
        """
        pass

    def compress(self, x):
        """Compress an image `x` into byte strings.
        """
        pass

    def decompress(self, strings, shape):
        """Decompress an image `x` given byte strings
        """
        pass

    @property
    def downscale_factor(self):
        """ Maximum down-scale factor
        """
        return 2 ** (4 + 2)


# Copied from CompressAI
class Cheng2020Model(MBT2018Model):
    """
    """
    def __init__(self, N=192, **kwargs):
        super().__init__(N=N, M=N, **kwargs)
        self.g_a = nn.Sequential(
            ResidualBlockWithStride(3, N, stride=2),
            ResidualBlock(N, N),
            ResidualBlockWithStride(N, N, stride=2),
            AttentionBlock(N),
            ResidualBlock(N, N),
            ResidualBlockWithStride(N, N, stride=2),
            ResidualBlock(N, N),
            conv3x3(N, N, stride=2),
            AttentionBlock(N),
        )
        self.g_s = nn.Sequential(
            AttentionBlock(N),
            ResidualBlock(N, N),
            ResidualBlockUpsample(N, N, 2),
            ResidualBlock(N, N),
            ResidualBlockUpsample(N, N, 2),
            AttentionBlock(N),
            ResidualBlock(N, N),
            ResidualBlockUpsample(N, N, 2),
            ResidualBlock(N, N),
            subpel_conv3x3(N, 3, 2),
        )
        self.h_a = nn.Sequential(
            conv3x3(N, N),
            nn.LeakyReLU(inplace=True),
            conv3x3(N, N),
            nn.LeakyReLU(inplace=True),
            conv3x3(N, N, stride=2),
            nn.LeakyReLU(inplace=True),
            conv3x3(N, N),
            nn.LeakyReLU(inplace=True),
            conv3x3(N, N, stride=2),
        )
        self.h_s = nn.Sequential(
            conv3x3(N, N),
            nn.LeakyReLU(inplace=True),
            subpel_conv3x3(N, N, 2),
            nn.LeakyReLU(inplace=True),
            conv3x3(N, N * 3 // 2),
            nn.LeakyReLU(inplace=True),
            subpel_conv3x3(N * 3 // 2, N * 3 // 2, 2),
            nn.LeakyReLU(inplace=True),
            conv3x3(N * 3 // 2, N * 2),
        )

