
lambda=4096
model_name=elich

export CUDA_VISIBLE_DEVICES="3"
python train.py \
-c ./cfgs/${model_name}-m${lambda}.yml \
-c ./cfgs/train_default_server38.yml \
--save_name ${model_name}-m${lambda} \
--ckpt_path /data1/fengrs/compression2022/compression/elicho-m4096/best.pth
#--ckpt_path /data1/fengrs/compression2022/compression/intra-m4096/best.pth


