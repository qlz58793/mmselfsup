import os
import sys
import yaml
import shutil
import argparse
import warnings
from pathlib import Path
from easydict import EasyDict as edict
from dotty_dict import dotty
import collections

import torch
import torch.optim as optim
from torch.optim.lr_scheduler import MultiStepLR
import torch.utils.data.distributed as data_dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import data_compression.datasets as datasets
import models

this_module = sys.modules[__name__]
# torch.set_num_threads(8)


def init_process_group(rank, world_size, master_port):
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = str(master_port)
    torch.distributed.init_process_group(
        "nccl", rank=rank, world_size=world_size
    )


def train(rank, args):
    print(f"Training model on rank {rank}.")
    device = torch.device(f'cuda:{rank}')
    if args.distributed:
        init_process_group(rank, args.n_gpus, args.master_port)

    # types determined by args
    train_set_type = getattr(datasets, args.train_set.name)
    model_type = getattr(models, args.model.name)
    optimizer_type = getattr(optim, args.optimizer.name)
    lr_scheduler_type = getattr(optim.lr_scheduler, args.lr_scheduler.name)

    # init dataloader
    print("Initializing dataloader...")
    train_set = train_set_type(**args.train_set.kwargs)
    sampler = torch.utils.data.RandomSampler(train_set)
    if args.distributed:
        # the actual batch size of DPP is batch_size * n_gpus.
        # therefore we divide batch_size by n_gpus
        args.train_loader.kwargs.batch_size //= args.n_gpus
        sampler = torch.utils.data.distributed.DistributedSampler(train_set)
    train_loader = torch.utils.data.DataLoader(
        dataset=train_set,
        sampler=sampler,
        **args.train_loader.kwargs
    )

    # init model
    print("Initializing model...")
    model = model_type(**args.model.kwargs).to(device)

    # repr
    save_dir = Path(args.output_dir) / args.save_name
    itr = args.last_iter
    ckpt_dir = save_dir / f"{save_dir.name}_ckpt"
    eval_results_dir = save_dir / "eval_results"

    # mkdir
    print(f"Saving at {save_dir}")
    save_dir.mkdir(parents=True, exist_ok=True)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    # load ckpt
    if args.ckpt_path is not None:
        ckpt = torch.load(args.ckpt_path)
        itr = ckpt["iter"] if itr is None else itr
        model.load_state_dict_custom(ckpt["params"], strict=False)
    itr = 0 if itr is None else itr
    print(f"Number of parameters"
          f": {sum(p.numel() for p in model.parameters()) / 1e6}M")
    
    # pre-evaluation
    print("Pre-evaluating...")
    rd_loss, log_str = model.evaluate(
        output_dir=eval_results_dir, **args.eval_kwargs)
    print(f"[Iteration {itr}]\n{log_str}")

    # set up optimizer and lr_scheduler
    params = filter(lambda p: p.requires_grad, model.parameters())
    optimizer = optimizer_type(params,  **args.optimizer.kwargs)
    lr_scheduler = lr_scheduler_type(optimizer, **args.lr_scheduler.kwargs)
    lr_scheduler.last_epoch = itr

    # train
    print("Training...")
    if args.distributed:
        model = DDP(model, device_ids=[rank], output_device=rank)
    n_epochs = 1 + (args.total_iter - itr) // len(train_loader)
    best_rd_loss, best_log_str = float('inf'), ''
    for epoch in range(n_epochs):
        if args.distributed:
            train_loader.sampler.set_epoch(epoch)
        for data in train_loader:
            itr += 1
            if itr > args.total_iter:
                break

            # forward and backward
            data = data.to(device, non_blocking=True)
            rd_loss = model(data, return_loss=True)
            optimizer.zero_grad()
            rd_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            lr_scheduler.step()

            # evaluate and save checkpoint
            if itr % args.eval_stride == 0 and rank == 0:
                _model = model.module if args.distributed else model
                _model.get_ready_for_compression()
                rd_loss, log_str = _model.evaluate(
                    output_dir=eval_results_dir, **args.eval_kwargs)

                # save the latest model and the best model
                state_dict = {"iter": itr, "params": _model.state_dict()}
                torch.save(state_dict, ckpt_dir / "all.pth")
                if rd_loss >= best_rd_loss:
                    log_str = f"[Iteration {itr}]\n{log_str}"
                else:
                    best_rd_loss = rd_loss
                    best_log_str = log_str
                    log_str = f"[Iteration {itr}] Best!!!\n{log_str}"
                    shutil.copytree(
                        ckpt_dir,
                        f"{ckpt_dir}_best"
                    )
                    shutil.copytree(
                        eval_results_dir,
                        f"{eval_results_dir}_best"
                    )
                print(log_str)

    if args.distributed:
        torch.distributed.destroy_process_group()
    print(f"[Summary] Best loss for {args.save_name}"
          f": {best_rd_loss:.6f}\n{best_log_str}\n")


def setup_args(parser):
    parser.add_argument(
         "-c", "--config_paths", type=Path, action='append', required=True,
        help="configuration file."
    )
    parser.add_argument(
        "--eval_kwargs.input_glob", type=Path,
        help=""
    )
    parser.add_argument(
        "--eval_kwargs.save_rec", type=bool,
        help=""
    )
    parser.add_argument(
        "--eval_kwargs.compression", type=bool,
        help=""
    )
    parser.add_argument(
        "--output_dir", type=Path,
        help=""
    )
    parser.add_argument(
        "--save_name", type=str,
        help=""
    )
    parser.add_argument(
        "--ckpt_path", type=Path,
        help=""
    )
    parser.add_argument(
        "--n_gpus", type=int,
        help=""
    )
    parser.add_argument(
        "--master_port", type=int,
        help=""
    )
    parser.add_argument(
        "--distributed", type=bool,
        help=""
    )
    parser.add_argument(
        "--last_iter", type=int,
        help=""
    )
    parser.add_argument(
        "--total_iter", type=int,
        help=""
    )
    parser.add_argument(
        "--eval_stride", type=int,
        help=""
    )
    parser.add_argument(
        "--optimizer.kwargs.lr", type=float,
        help=""
    )


def namespace_to_easydict(namespace):
    out = dotty()
    for k, v in vars(namespace).items():
        out[k] = v
    return edict(out)


def nested_update(dict1, dict2, ignore_none=True):
    for k, v in dict2.items():
        if isinstance(v, collections.abc.Mapping):
            dict1[k] = nested_update(dict1.get(k, {}), v)
        else:
            if k in dict1.keys() and v is None and ignore_none :
                continue
            dict1[k] = v
    return dict1


def update_cfgs_using_args(args, cfg_ps):
    cfgs = edict()
    for cfg_p in cfg_ps:
        cfg = yaml.load(open(cfg_p, 'r'), Loader=yaml.FullLoader)
        # cfgs.update(cfg)
        nested_update(cfgs, cfg)
    cfgs = dotty(cfgs)
    # cfgs.update(args)
    nested_update(cfgs, args)
    return cfgs


def check_args(args):
    # optional_keys = ["ckpt_path"]
    # for k, v in args.items():
    #     if k not in optional_keys and v is None:
    #         raise AttributeError(f"Please set '{k}'")
    if not hasattr(models, args.model.name):
        raise Exception(f"No model named {args.model.name}")
    if not hasattr(datasets, args.train_set.name):
        raise Exception(f"No dataset named {args.train_set.name}")
    if not hasattr(optim, args.optimizer.name):
        raise Exception(f"No optimizer named {args.optimizer.name}")
    if not hasattr(optim.lr_scheduler, args.lr_scheduler.name):
        raise Exception(f"No lr_scheduler named {args.lr_scheduler.name}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    setup_args(parser)
    args = parser.parse_args(sys.argv[1:])
    args = namespace_to_easydict(args)
    cfg_ps = args.pop("config_paths")
    args = update_cfgs_using_args(args, cfg_ps)
    check_args(args)
    print(args)
    
    if args.n_gpus > 1 and not args.distributed:
        warnings.warn(
            f"Only one gpu is used while {args.n_gpus} gpus"
            f" are available! Set train.n_gpus=1 or train.distributed=True."
        )
    if args.distributed:
        mp.spawn(
            train,
            args=(args,),
            nprocs=args.n_gpus,
            join=True
        )
    else:
        train(0, args)