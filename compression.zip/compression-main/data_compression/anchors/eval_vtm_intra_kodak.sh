#!/usr/bin/env bash
save_name=vtm18-intra
cfg_name=encoder_intra_vtm
set_name=kodak

python main.py vtm \
--input_space rgb24 \
-i "/data1/datasets/${set_name}/*.png" \
--output_space rgb24 \
-o /data1/fengrs/coding_results/${set_name}/${save_name}  \
-b /home/fengrs/compression2022/coding_standards/VVCSoftware_VTM-VTM-18.2/bin \
-c /home/fengrs/compression2022/coding_standards/VVCSoftware_VTM-VTM-18.2/cfg/${cfg_name}.cfg \
-q {50..10..-2} \
-p 24 \
> /data1/fengrs/coding_results/${set_name}-${save_name}.json