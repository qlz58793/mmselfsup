import glob
import sys
import argparse
import subprocess
from pathlib import Path


def run_cli(cli):
	try:
		out_bytes = subprocess.check_output(
			cli, shell=True, stderr=subprocess.STDOUT)
		return out_bytes.decode('utf-8')
	except subprocess.CalledProcessError as e:
		print(e.output.decode('utf-8'))


def parse_size_from_stem(stem):
	for s in stem.split("_"):
		try:
			size = list(map(int, s.split("x")))
			assert len(size) == 2
			return size
		except:
			pass
	return None


def run(args):
	input_ps = sorted(glob.glob(args.input_glob))
	for input_p in input_ps:
		input_p = Path(input_p)
		wdt, hgt = parse_size_from_stem(input_p.stem)
		output_p = Path(args.output_dir) / input_p.stem / "%06d.png"
		output_p.parent.mkdir(parents=True, exist_ok=True)
		cli = [
			"ffmpeg",
			"-y",
			"-loglevel error",
			f"-s {wdt}x{hgt}",
			f"-pix_fmt {args.input_space}",
			f"-i {input_p}",
			f"-pix_fmt {args.output_space}",
			f"{output_p}"
		]
		cli = " ".join(cli)
		# print(cli)
		run_cli(cli)


def setup_args(parser):
	parser.add_argument(
		"-i", "--input_glob", type=str, required=True,
		help="input path in glob pattern"
	)
	parser.add_argument(
		"-o", "--output_dir", type=str,
		help="output directory"
	)
	parser.add_argument(
		"--input_space", choices=["yuv420p", "yuv444p", "rgb24"],
		help="input color space"
	)
	parser.add_argument(
		"--output_space", choices=["yuv420p", "yuv444p", "rgb24"],
		help="output color space"
	)


if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	setup_args(parser)
	args = parser.parse_args(sys.argv[1:])
	run(args)
