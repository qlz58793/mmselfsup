#!/usr/bin/env bash


## jctvc
#for name in ClassB ClassC ClassD ClassE
#do
#python ffmpeg.py \
#--input_space yuv420p \
#-i "/data1/datasets/jctvc/test_sequences/${name}/*.yuv" \
#--output_space rgb24 \
#-o "/data1/datasets/jctvc/test_sequences_rgb24/${name}"
#done
#
## uvg
#python ffmpeg.py \
#--input_space yuv420p \
#-i "/data1/datasets/uvg/test_sequences/*.yuv" \
#--output_space rgb24 \
#-o "/data1/datasets/uvg/test_sequences_rgb24"


# mcljcv
python ffmpeg.py \
--input_space yuv420p \
-i "/data1/datasets/mcljcv/test_sequences/*.yuv" \
--output_space rgb24 \
-o "/data1/datasets/mcljcv/test_sequences_rgb24"
