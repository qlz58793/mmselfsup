#!/usr/bin/env bash
save_name=hm16-lowdelay-ip32
cfg_name=encoder_lowdelay_main
set_name=jctvc

for subset_name in ClassD ClassC ClassE ClassB
do
  python main.py hm \
  --input_space rgb24 \
  -i "/data1/datasets/${set_name}/test_sequences_rgb24/${subset_name}/*" \
  --output_space rgb24 \
  -o /data1/fengrs/coding_results/${set_name}/${subset_name}/${save_name}   \
  -b /home/fengrs/compression2022/coding_standards/HM-HM-16.26/bin \
  -c /home/fengrs/compression2022/coding_standards/HM-HM-16.26/cfg/${cfg_name}.cfg \
  -ip 32 \
  -f 96 \
  -q 34 32 30 28 26 24 22 \
  -p 12 \
  > /data1/fengrs/coding_results/${set_name}-${subset_name}-${save_name}.json
done



