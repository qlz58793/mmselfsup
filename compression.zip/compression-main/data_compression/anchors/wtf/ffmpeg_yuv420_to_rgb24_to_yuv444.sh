#!/usr/bin/env bash


ffmpeg \
-y \
-s 416x240 \
-pix_fmt yuv420p \
-i /data1/datasets/jctvc/test_sequences/ClassD/BasketballPass_416x240_50.yuv \
-pix_fmt yuv444p \
/data1/fengrs/coding_results/ffmpeg_yuv444p_1nd/BasketballPass_416x240_50.yuv

ffmpeg \
-y \
-s 416x240 \
-pix_fmt yuv420p \
-i /data1/datasets/jctvc/test_sequences/ClassD/BasketballPass_416x240_50.yuv \
-pix_fmt rgb24 \
/data1/fengrs/coding_results/ffmpeg_rgb24/%06d.png

ffmpeg \
-y \
-s 416x240 \
-pix_fmt rgb24 \
-i /data1/fengrs/coding_results/ffmpeg_rgb24/%06d.png \
-pix_fmt yuv444p \
/data1/fengrs/coding_results/ffmpeg_yuv444p_2nd/BasketballPass_416x240_50.yuv

