import os
import gc
import abc
import glob
import time
import shutil
import tempfile
import subprocess
from pathlib import Path
import multiprocessing as mp
from memory_profiler import profile
from typing import List, Tuple
from collections import defaultdict
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
from pytorch_msssim import ms_ssim

__all__ = [
	"VTM",
	"HM"
]
KRKGKB_TABLE = {
	"Rec.601": (0.299, 0.587, 0.114),
	"Rec.709": (0.2126, 0.7152, 0.0722),
	"Rec.2020": (0.2627, 0.678, 0.0593)
}
ITU_R_VERSION = "Rec.709"


def run_cli(cli):
	try:
		out_bytes = subprocess.check_output(
			cli, shell=True, stderr=subprocess.STDOUT)
		return out_bytes.decode('utf-8')
	except subprocess.CalledProcessError as e:
		print(e.output.decode('utf-8'))


def file_size(p):
	return Path.stat(Path(p)).st_size


def mkstemp(suffix, dir=None):
	fd, path = tempfile.mkstemp(suffix=f"{suffix}", dir=dir)
	os.close(fd)
	return Path(path)

#@profile
def rgb_to_ycbcr(rgb: np.ndarray, data_range: float = 255.) -> np.ndarray:
	if data_range == 255.:
		rgb = rgb.astype(np.float32)
		rgb = rgb / data_range
	kr, kg, kb = KRKGKB_TABLE[ITU_R_VERSION]
	r, g, b = np.split(rgb, 3, axis=-3)
	# transform
	y = r * kr + g * kg + b * kb
	cb = r * (-0.5 * kr / (1 - kb)) + g * (-0.5 * kg / (1 - kb)) + b * 0.5
	cr = r * 0.5 + g * (-0.5 * kg / (1 - kr)) + b * (-0.5 * kb / (1 - kr))
	del(rgb, r, g, b)
	# move cb, cr from [-0.5, 0.5] to [0, 1]
	cb = cb + 0.5
	cr = cr + 0.5
	ycbcr = np.concatenate((y, cb, cr), axis=-3)
	ycbcr = ycbcr.clip(0, 1)
	if data_range == 255.:
		ycbcr = ycbcr * data_range
		ycbcr = ycbcr.round().astype(np.uint8)
	return ycbcr

#@profile
def ycbcr_to_rgb(ycbcr: np.ndarray, data_range: float = 255.) -> np.ndarray:
	if data_range == 255.:
		ycbcr = ycbcr.astype(np.float32)
		ycbcr = ycbcr / data_range
	kr, kg, kb = KRKGKB_TABLE[ITU_R_VERSION]
	y, cb, cr = np.split(ycbcr, 3, axis=-3)
	# move cb, cr from [0, 1] to [-0.5, 0.5]
	cb = cb - 0.5
	cr = cr - 0.5
	# transform
	r = y + cr * (2 - 2 * kr)
	g = y + cb * (-kb / kg * (2 - 2 * kb)) + cr * (-kr / kg * (2 - 2 * kr))
	b = y + cb * (2 - 2 * kb)
	del (ycbcr, y, cb, cr)
	rgb = np.concatenate((r, g, b), axis=-3)
	rgb = rgb.clip(0, 1)
	if data_range == 255.:
		rgb = rgb * data_range
		rgb = rgb.round().astype(np.uint8)
	return rgb


def yuv444p_to_yuv420p(yuv: np.ndarray, data_range: float = 255.) \
		-> List[np.ndarray]:
	"""B, C, H, W or C, H, W"""
	y, u, v = np.split(yuv, 3, axis=-3)

	def _downscale(x: np.ndarray) -> np.ndarray:
		if data_range == 255.:
			x = x.astype(np.float32)
		ndim = len(x.shape)
		if ndim == 3:
			x = np.expand_dims(x, 0)
		x = torch.from_numpy(x)
		x = F.avg_pool2d(x, kernel_size=2, stride=2)
		x = x.numpy()
		if ndim == 3:
			x = x.squeeze(0)
		if data_range == 255.:
			x = x.round().astype(np.uint8)
		return x

	u, v = list(map(_downscale, [u, v]))
	return YUV420Channel([y, u, v])


def yuv420p_to_yuv444p(yuv: List[np.ndarray], data_range: float = 255.) \
		-> np.ndarray:
	"""B, C, H, W or C, H, W"""
	y, u, v = yuv

	def _upscale(x: np.ndarray) -> np.ndarray:
		if data_range == 255.:
			x = x.astype(np.float32)
		ndim = len(x.shape)
		if ndim == 3:
			x = np.expand_dims(x, 0)
		x = torch.from_numpy(x)
		x = F.interpolate(
			x,
			# mode="nearest",
			mode="bilinear", align_corners=False,
			scale_factor=2,
		)
		x = x.numpy()
		if ndim == 3:
			x = x.squeeze(0)
		if data_range == 255.:
			x = x.round().astype(np.uint8)
		return x

	u, v = list(map(_upscale, [u, v]))
	yuv = np.concatenate((y, u, v), axis=-3)
	return yuv


#@profile
def measure_quality(ori, rec, data_range=255., psnr_only=False):
	"""Measure the quality of two sequences.(shape: (B, C, H, W))
	"""
	assert ori.shape[0] == rec.shape[0]
	n_frames = ori.shape[0]
	psnrs, msssims = [], []
	for i in range(n_frames):
		if ori.dtype != np.float32:
			ori_i = ori[i:i + 1].astype(np.float32)
			rec_i = rec[i:i + 1].astype(np.float32)
		psnr = 20 * np.log10(data_range) \
		       - 10 * np.log10(((ori_i - rec_i) ** 2).mean())
		if psnr_only:
			msssim = 0
		else:
			msssim = ms_ssim(
				torch.from_numpy(ori_i),
				torch.from_numpy(rec_i),
				data_range=data_range
			).item()
		psnrs.append(float(psnr))
		msssims.append(float(msssim))

	psnr = sum(psnrs) / len(psnrs)
	msssim = sum(msssims) / len(msssims)
	return psnr, msssim, psnrs, msssims


def parse_size_from_stem(stem):
	for s in stem.split("_"):
		try:
			size = list(map(int, s.split("x")))
			assert len(size) == 2
			return size
		except:
			pass
	return None


def parse_space_from_suffix(suffix):
	""""""
	if suffix == ".yuv":
		space = "yuv444p"
	else:
		space = "rgb24"
	return space


def load_file(file_p, color_space=None, wdt=None, hgt=None, n_frames=None):
	"""Load file"""
	file_p = Path(file_p)
	if file_p.suffix in [".yuv", ".rgb"]:
		if wdt is None or hgt is None:
			wdt, hgt = parse_size_from_stem(file_p.stem)
		n_pix = wdt * hgt
		if color_space in ["yuv444p", "rgb24"]:
			n_element = n_pix * 3
			if n_frames is None:
				n_frames = file_size(file_p) // n_element
			else:
				n_frames = min(n_frames, file_size(file_p) // n_element)
			x = np.fromfile(file_p, dtype=np.uint8, count=n_frames * n_element)
			x = x.reshape(n_frames, 3, hgt, wdt)
		elif color_space == "yuv420p":
			n_element = n_pix * 3 // 2
			if n_frames is None:
				n_frames = file_size(file_p) // n_element
			else:
				n_frames = min(n_frames, file_size(file_p) // n_element)
			x = np.fromfile(file_p, dtype=np.uint8, count=n_frames * n_element)
			x = x.reshape(n_frames, n_element)
			y = x[:, :n_pix]
			u = x[:, n_pix:n_pix * 5 // 4]
			v = x[:, n_pix * 5 // 4:]
			x = YUV420Channel([y, u, v], wdt=wdt, hgt=hgt)
	else:
		x = Image.open(file_p).convert('RGB')
		x = np.asarray(x).transpose((2, 0, 1))
		x = x.reshape(1, *x.shape)
	return x

#@profile
def load_files(file_ps, color_space=None, wdt=None, hgt=None, n_frames=None):
	"""Load files"""
	assert color_space != "yuv420p"
	x = []
	for i, file_p in enumerate(file_ps[:n_frames]):
		x.append(load_file(file_p, color_space, wdt, hgt))
	x = np.concatenate(x)
	x = x[:n_frames].copy()
	return x


def save_file(x, file_p, color_space):
	"""Save file"""
	file_p = Path(file_p)
	if file_p.suffix in [".yuv", ".rgb"]:
		if color_space == "yuv420p":
			x = np.concatenate(x.flatten())
		x.astype(np.uint8).tofile(file_p)
	else:
		assert x.shape[0] == 1
		x = x.squeeze(0)
		x = x.astype(np.uint8).transpose((1, 2, 0))
		Image.fromarray(x).save(file_p)


def save_files(x, file_ps: List, color_space):
	"""Save files"""
	assert len(x) == len(file_ps)
	for i, file_p in enumerate(file_ps):
		save_file(x[i:i+1], file_p, color_space)


class YUV420Channel(list):
	def __init__(self, seq: List[np.ndarray], wdt=None, hgt=None):
		assert len(seq) == 3
		if wdt is None or hgt is None:
			hgt, wdt = seq[0].shape[-2:]
		seq[0] = seq[0].reshape((-1, 1, hgt, wdt))
		seq[1] = seq[1].reshape((-1, 1, hgt // 2, wdt // 2))
		seq[2] = seq[2].reshape((-1, 1, hgt // 2, wdt // 2))
		self.seq = seq
		super().__init__(seq)

	def __getitem__(self, slice):
		return YUV420Channel(list(map(lambda x: x[slice], self.seq)))

	def flatten(self):
		assert hasattr(self.seq[0], "flatten")
		return YUV420Channel(list(map(lambda x: x.flatten(), self.seq)))

	def copy(self):
		return YUV420Channel(list(map(lambda x: x.copy(), self.seq)))

	@property
	def shape(self):
		shape = list(self.seq[0].shape)
		shape[1] = 1.5
		return tuple(shape)


def convert_colorspace(x, in_space, out_space):
	if in_space == out_space:
		x = x
	elif in_space == "yuv444p" and out_space == "rgb24":
		x = ycbcr_to_rgb(x)
	elif in_space == "rgb24" and out_space == "yuv444p":
		x = rgb_to_ycbcr(x)
	elif in_space == "yuv444p" and out_space == "yuv420p":
		x = yuv444p_to_yuv420p(x)
	elif in_space == "yuv420p" and out_space == "yuv444p":
		x = yuv420p_to_yuv444p(x)
	elif in_space == "yuv420p" and out_space == "rgb24":
		x = yuv420p_to_yuv444p(x)
		x = ycbcr_to_rgb(x)
	elif in_space == "rgb24" and out_space == "yuv420p":
		x = rgb_to_ycbcr(x)
		x = yuv444p_to_yuv420p(x)
	else:
		raise NotImplementedError(f"{in_space}->{out_space}")
	return x


class EvaluatorBase(metaclass=abc.ABCMeta):
	coding_space_table = []
	yuv_space_table = ["yuv420p", "yuv444p"]
	rgb_space_table = ["rgb24"]
	input_space_table = yuv_space_table + rgb_space_table
	output_space_table = input_space_table
	eval_space_table = ["yuv444p", "rgb24"]

	def __init__(self, args):
		self.input_glob = args.input_glob
		self.processes = args.processes
		self.qps = args.qps
		self.input_space = args.input_space
		self.output_space = args.output_space
		self.coding_space = args.coding_space
		self.eval_space = args.eval_space
		self.output_dir = None
		self.tmp_dir = None
		self.wdt = None
		self.hgt = None
		self.n_frames = args.n_frames
		self.TemporalSubsampleRatio = args.TemporalSubsampleRatio
		self.IntraPeriod = args.IntraPeriod
		if args.output_dir is not None:
			self.output_dir = Path(args.output_dir)
			self.output_dir.mkdir(parents=True, exist_ok=True)
			self.tmp_dir = self.output_dir / "do_not_delete_this_when_coding"
			shutil.rmtree(self.tmp_dir, ignore_errors=True)
			self.tmp_dir.mkdir(parents=True, exist_ok=True)
		if args.size is not None:
			size = list(map(int, args.size.split("x")))
			assert len(size) == 2
			self.wdt, self.hgt = size

	@classmethod
	def setup_args(cls, parser):
		parser.add_argument(
			"-i", "--input_glob", type=str, required=True,
			help="input path in glob pattern"
		)
		parser.add_argument(
			"-o", "--output_dir", type=str,
			help="output directory"
		)
		parser.add_argument(
			"-p", "--processes", type=int, metavar="N", default=1,
			help="number of parallel processes (default: %(default)s)"
		)
		parser.add_argument(
			"-q", "--qps", type=int, metavar="Q", default=[31], nargs="+",
			help="list of quantization parameter (default: %(default)s)"
		)
		parser.add_argument(
			"-s", "--size", type=str,
			help="spatial resolution [wdt]x[hgt] (optional)"
		)
		parser.add_argument(
			"-f", "--n_frames", type=int,
			help="specifies the number of frames to be encoded."
		)
		parser.add_argument(
			"-ip", "--IntraPeriod", type=int, default=-1,
			help="the intra frame period."
		)
		parser.add_argument(
			"-ts", "--TemporalSubsampleRatio", type=int, default=1,
			help=" A value of N will skip (N − 1) frames of input video "
			     "after each coded input video frame. "
		)
		parser.add_argument(
			"--input_space", choices=cls.input_space_table,
			help="input color space"
		)
		parser.add_argument(
			"--output_space", choices=cls.output_space_table,
			help="output color space"
		)
		parser.add_argument(
			"--coding_space", choices=cls.coding_space_table,
			default="yuv444p",
			help="coding color space (default: %(default)s)"
		)
		parser.add_argument(
			"--eval_space", choices=cls.eval_space_table,
			default="rgb24",
			help="evaluation color space (default: %(default)s)"
		)

	def evaluate(self):
		input_ps = glob.glob(self.input_glob)
		processes = min(self.processes, len(input_ps) * len(self.qps))
		with mp.Pool(processes) as pool:
			logouts = pool.starmap(
				self.evaluate_one_file_one_qp,
				[(input_p, qp) for qp in self.qps for input_p in input_ps]
			)
		results = defaultdict(lambda: [0 for _ in self.qps])
		results["codec"] = type(self).__name__
		results["input_space"] = self.input_space
		results["coding_space"] = self.coding_space
		results["eval_space"] = self.eval_space
		results["num_files"] = len(input_ps)
		results["qps"] = self.qps
		for i in range(len(self.qps)):
			for j in range(len(input_ps)):
				for k, v in logouts[i * len(input_ps) + j].items():
					results[k][i] += v / len(input_ps)
		return results

	#@profile
	def evaluate_one_file_one_qp(self, input_p, qp):
		input_p = Path(input_p)
		input_space = self.input_space
		output_space = self.output_space
		coding_space = self.coding_space
		eval_space = self.eval_space
		ts = self.TemporalSubsampleRatio
		ip = self.IntraPeriod
		if input_space is None:
			input_space = parse_space_from_suffix(input_p.suffix)
		if output_space is None:
			output_space = input_space

		# load file -> input_space
		if input_p.is_dir():
			input_ps = sorted(input_p.iterdir())
			ori = load_files(
				input_ps, input_space, self.wdt, self.hgt, self.n_frames)
		else:
			ori = load_file(
				input_p, input_space, self.wdt, self.hgt, self.n_frames)
		hgt, wdt = ori.shape[2], ori.shape[3]

		tmp_p = mkstemp(
			suffix=f"_{wdt}x{hgt}.yuv", dir=self.tmp_dir)
		tmp_bin_p = tmp_p.with_suffix(".bin")
		tmp_log_p = tmp_p.with_suffix(".log")

		## change input_space to rgb24 (optional)
		# ori = convert_colorspace(ori, input_space, "rgb24")
		# input_space = "rgb24"

		# input_space -> coding_space -> file
		tmp = convert_colorspace(ori, input_space, coding_space)
		n_frames_enc = tmp.shape[0]
		save_file(tmp, tmp_p, coding_space)

		if ts > 1:
			ori = ori[::ts].copy()

		# compress decompress
		t0 = time.time()
		self.compress(
			tmp_p, tmp_bin_p, qp, wdt, hgt, n_frames_enc, ip, ts, tmp_log_p)
		t1 = time.time()
		self.decompress(tmp_bin_p, tmp_p)
		t2 = time.time()
		# file -> coding_space
		tmp = load_file(tmp_p, coding_space, wdt, hgt)
		n_frames_dec = tmp.shape[0]

		# evaluation
		psnr, msssim, psnrs, msssims = measure_quality(
			convert_colorspace(ori, input_space, eval_space),
			convert_colorspace(tmp, coding_space, eval_space)
		)
		del(ori)
		bpp = file_size(tmp_bin_p) * 8.0 / (wdt * hgt * n_frames_dec)
		bits = self.parse_bits_from_log(tmp_log_p)
		bpps = [b / (wdt * hgt) for b in bits]
		os.unlink(tmp_p)
		os.unlink(tmp_bin_p)
		os.unlink(tmp_log_p)

		# save reconstruction
		if self.output_dir is not None:
			# input_space -> output_space
			rec = convert_colorspace(tmp, coding_space, output_space)
			# save file
			suffix = ".png" if output_space in self.rgb_space_table else ".yuv"
			seq_stem = [
				input_p.stem,
				f"nframes{n_frames_dec}",
				f"bpp{bpp:.4f}",
				f"psnr{psnr:.2f}",
				f"msssim{msssim:.4f}"
			]
			seq_stem = "_".join(seq_stem)

			if n_frames_dec > 1 and suffix == ".png":
				rec_ps = []
				for i in range(len(psnrs)):
					frame_stem = [
						f"{i+1:0>6}",
						f"bpp{bpps[i]:.4f}",
						f"psnr{psnrs[i]:.2f}",
						f"msssim{msssims[i]:.4f}"
					]
					frame_stem = "_".join(frame_stem)
					rec_name = frame_stem + suffix
					rec_p = self.output_dir / f"q{qp:0>2d}" / \
					        seq_stem / rec_name
					rec_ps.append(rec_p)
				rec_ps[0].parent.mkdir(parents=True, exist_ok=True)
				save_files(rec, rec_ps, output_space)
			else:
				rec_name = seq_stem + suffix
				rec_p = self.output_dir / f"q{qp:0>2d}" / rec_name
				rec_p.parent.mkdir(parents=True, exist_ok=True)
				save_file(rec, rec_p, output_space)

		del(tmp, rec)
		logout = {
			"bpp": bpp,
			"psnr": psnr,
			"ms-ssim": msssim,
			"encoding_time": t1 - t0,
			"decoding_time": t2 - t1,
		}
		return logout

	@abc.abstractmethod
	def parse_bits_from_log(self, log_p):
		raise NotImplementedError

	@abc.abstractmethod
	def compress(self, input_p, bin_p, qp, wdt, hgt, n_frames, ip, ts, log_p):
		raise NotImplementedError

	@abc.abstractmethod
	def decompress(self, bin_p, output_p):
		raise NotImplementedError


class VTM(EvaluatorBase):
	bit_depth = 8
	coding_space_table = ["yuv444p", 'rgb24']

	def __init__(self, args):
		super().__init__(args)
		self.encoder_p = args.build_dir / "EncoderAppStatic"
		self.decoder_p = args.build_dir / "DecoderAppStatic"
		self.config_p = args.config_path

	@classmethod
	def setup_args(cls, parser):
		super().setup_args(parser)
		parser.add_argument(
			"-b", "--build_dir", type=Path, required=True,
			help="VTM build dir"
		)
		parser.add_argument(
			"-c", "--config_path", type=Path, required=True,
			help="VTM configuration file"
		)

	def parse_bits_from_log(self, log_p):
		with open(log_p, "r") as fp:
			lines = fp.readlines()
		bits = []
		for line in lines:
			if "POC" in line:
				slice_index = 12
				bits.append(int(line.split()[slice_index]))
		return bits

	def compress(self, input_p, bin_p, qp, wdt, hgt, n_frames, ip, ts, log_p):
		cli = [
			self.encoder_p.as_posix(),
			f"-i {input_p}",
			f"-c {self.config_p.as_posix()}",
			f"-q {qp}",
			f"-o /dev/null",
			f"-b {bin_p}",
			f"-wdt {wdt}",
			f"-hgt {hgt}",
			"-fr 1",
			f"-ts {ts}",
			f"-f {n_frames}",
			"--InputChromaFormat=444",
			f"--InputBitDepth={self.bit_depth}",
			"--ConformanceWindowMode=1",
			f"> {log_p}" if log_p is not None else ""
		]
		if n_frames == 1:
			cli += [f"-ip 1"]
		else:
			cli += [f"-ip {ip}", f"--DecodingRefreshType=2"]
		if self.coding_space == "rgb24":
			cli += [
				"--InputColourSpaceConvert=RGBtoGBR",
				"--SNRInternalColourSpace=1",
			]
		run_cli(' '.join(cli))

	def decompress(self, bin_p, output_p):
		cli = [
			self.decoder_p.as_posix(),
			f"-b {bin_p}",
			f"-o {output_p}",
			f"-d {self.bit_depth}"
		]
		if self.coding_space == "rgb24":
			cli += [
				"--OutputColourSpaceConvert=GBRtoRGB"
			]
		run_cli(' '.join(cli))


class HM(EvaluatorBase):
	bit_depth = 8
	coding_space_table = ["yuv444p", 'rgb24']

	def __init__(self, args):
		super().__init__(args)
		self.encoder_p = args.build_dir / "TAppEncoderStatic"
		self.decoder_p = args.build_dir / "TAppDecoderStatic"
		self.config_p = args.config_path

	@classmethod
	def setup_args(cls, parser):
		super().setup_args(parser)
		parser.add_argument(
			"-b", "--build_dir", type=Path, required=True,
			help="HM build dir"
		)
		parser.add_argument(
			"-c", "--config_path", type=Path, required=True,
			help="HM configuration file"
		)

	def parse_bits_from_log(self, log_p):
		with open(log_p, "r") as fp:
			lines = fp.readlines()
		bits = []
		for line in lines:
			if "POC" in line:
				slice_index = 11
				bits.append(int(line.split()[slice_index]))
		return bits

	def compress(self, input_p, bin_p, qp, wdt, hgt, n_frames, ip, ts, log_p):
		cli = [
			self.encoder_p.as_posix(),
			f"-i {input_p}",
			f"-c {self.config_p.as_posix()}",
			f"-q {qp}",
			f"-o /dev/null",
			f"-b {bin_p}",
			f"-wdt {wdt}",
			f"-hgt {hgt}",
			"-fr 1",
			f"-ts {ts}",
			f"-f {n_frames}",
			"--Profile=main_444",
			"--InputChromaFormat=444",
			f"--InputBitDepth={self.bit_depth}",
			"--ConformanceWindowMode=1",
			f"> {log_p}" if log_p is not None else ""
		]
		if n_frames == 1:
			cli += [f"-ip 1"]
		else:
			cli += [f"-ip {ip}", f"--DecodingRefreshType=2"]
		if self.coding_space == "rgb24":
			cli += [
				"--InputColourSpaceConvert=RGBtoGBR",
				"--SNRInternalColourSpace=1",
			]
		run_cli(' '.join(cli))

	def decompress(self, bin_p, output_p):
		cli = [
			self.decoder_p.as_posix(),
			f"-b {bin_p}",
			f"-o {output_p}",
			f"-d {self.bit_depth}"
		]
		if self.coding_space == "rgb24":
			cli += [
				"--OutputColourSpaceConvert=GBRtoRGB"
			]
		run_cli(' '.join(cli))