import sys
import json
import argparse
import evaluators
import torch

torch.set_num_threads(4)
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(
        dest="codec_name", required=True, help="select a codec")
    for name in evaluators.__all__:
        subparser = subparsers.add_parser(name.lower(), help=name)
        getattr(evaluators, name).setup_args(subparser)
    args = parser.parse_args(sys.argv[1:])

    evaluator = getattr(evaluators, args.codec_name.upper())(args)
    results = evaluator.evaluate()
    results = json.dumps(results, indent=4)
    print(results)
