#!/usr/bin/env bash
save_name=hm16-intra
cfg_name=encoder_intra_main
set_name=tecnick

python main.py hm \
--input_space rgb24 \
-i "/data1/datasets/${set_name}/RGB/RGB_OR_1200x1200/*.png" \
--output_space rgb24 \
-o /data1/fengrs/coding_results/${set_name}/${save_name}  \
-b /home/fengrs/compression2022/coding_standards/HM-HM-16.26/bin \
-c /home/fengrs/compression2022/coding_standards/HM-HM-16.26/cfg/${cfg_name}.cfg \
-q {50..10..-2} \
-p 4 \
> /data1/fengrs/coding_results/${set_name}-${save_name}.json