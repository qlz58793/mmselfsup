#!/usr/bin/env bash
keyword=tecnick

ps aux | grep ${keyword} |  awk '{print $2}' | xargs kill -9