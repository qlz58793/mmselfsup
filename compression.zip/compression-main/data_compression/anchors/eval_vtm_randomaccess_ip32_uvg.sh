#!/usr/bin/env bash
save_name=vtm18-randomaccess-ip32
cfg_name=encoder_randomaccess_vtm_gop16
set_name=uvg

python main.py vtm \
--input_space rgb24 \
-i "/data1/datasets/${set_name}/test_sequences_rgb24/*" \
--output_space rgb24 \
-o /data1/fengrs/coding_results/${set_name}/${save_name}   \
-b /home/fengrs/compression2022/coding_standards/VVCSoftware_VTM-VTM-18.2/bin \
-c /home/fengrs/compression2022/coding_standards/VVCSoftware_VTM-VTM-18.2/cfg/${cfg_name}.cfg \
-ip 32 \
-f 96 \
-q 34 32 30 28 26 24 22 \
-p 12 \
> /data1/fengrs/coding_results/${set_name}-${save_name}.json




