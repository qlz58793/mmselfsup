import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = [
    "ResBlock",
    "ResBlocks",
    "Downsample",
    "Upsample",
    "MaskedConv2d"
]

class ResBlock(nn.Module):
    def __init__(self, c, ks=3):
        super().__init__()
        self.m = nn.Sequential(
            nn.Conv2d(c, c, ks, 1, ks//2),
            nn.ReLU(),
            nn.Conv2d(c, c, ks, 1, ks//2)
        )
    def forward(self, x):
        return x + self.m(x)


class ResBlocks(nn.Module):
    def __init__(self, c, n=3, ks=3):
        super().__init__()
        self.m = nn.Sequential(
            *([ResBlock(c, ks) for _ in range(n)])
        )
    def forward(self, x):
        return x + self.m(x)


class Downsample(nn.Module):

    def __init__(self, c_in, c_out, factor=2):
        super().__init__()
        self.m = nn.Sequential(
            nn.PixelUnshuffle(factor),
            nn.Conv2d(c_in * factor ** 2, c_out, 1, 1, 0),
        )

    def forward(self, x):
        return self.m(x)


class Upsample(nn.Module):

    def __init__(self, c_in, c_out, factor=2):
        super().__init__()
        self.m = nn.Sequential(
            nn.Conv2d(c_in, c_out * factor ** 2, 1, 1, 0),
            nn.PixelShuffle(factor),
        )

    def forward(self, x):
        return self.m(x)


class MaskedConv2d(nn.Conv2d):
    def __init__(self, *args, **kwargs):
        super(MaskedConv2d, self).__init__(*args, **kwargs)
        self.register_buffer('mask', self.weight.data.clone())
        _, _, kH, kW = self.weight.size()
        self.mask.fill_(1)
        self.mask[:, :, kH // 2, kW // 2:] = 0
        self.mask[:, :, kH // 2 + 1:, :] = 0

    def forward(self, x):
        self.weight.data *= self.mask
        return super(MaskedConv2d, self).forward(x)