import lmdb
import io
import glob
from PIL import Image
from pathlib import Path

import torch
import torch.utils.data as data
from torchvision import transforms
import data_compression.datasets.video_transforms as video_transforms


class ImageLmdbDataset(data.Dataset):
    def __init__(self, root_dir, crop_size):
        self.root_dir = root_dir
        self.crop_size = crop_size

        # Delay loading LMDB data until after initialization to avoid "can't
        # pickle Environment Object error"
        self.env, self.txn = None, None
        with lmdb.open(root_dir, readonly=True, lock=False,
                             readahead=False, meminit=False) as env:
            with env.begin(write=False) as txn:
                self.n_samples = int(txn.get("num-samples".encode()))

        self.transform = transforms.Compose([
            transforms.RandomCrop(crop_size),
            transforms.ToTensor()
        ])

    def _init_db(self):
        self.env = lmdb.open(self.root_dir, readonly=True, lock=False,
                             readahead=False, meminit=False)
        self.txn = self.env.begin(write=False)

    def __getitem__(self, index):
        # Delay loading LMDB data until after initialization:
        # https://github.com/chainer/chainermn/issues/129
        if self.env is None:
            self._init_db()
        img_key = 'img-{:0>9}'.format(index + 1)
        img_bin = self.txn.get(img_key.encode())
        img = Image.open(io.BytesIO(img_bin))
        img = img.convert('RGB')
        img = self.transform(img)
        return img

    def __len__(self):
        return self.n_samples


class ImageGlobDataset(data.Dataset):
    def __init__(self, globs, crop_size=None):
        self.img_globs = globs
        self.img_ps = self.globs_to_paths(globs)
        if crop_size is not None:
            self.transform = transforms.Compose([
                transforms.RandomCrop(crop_size),
                transforms.ToTensor()
            ])
        else:
            self.transform = transforms.Compose([
                transforms.ToTensor()
            ])

    @staticmethod
    def globs_to_paths(globs):
        """ Convert a list of globs to a list of paths.
        """
        paths = []
        for g in globs:
            paths += glob.glob(g)
        paths = sorted(paths)
        return paths

    def __len__(self):
        return len(self.img_ps)

    def __getitem__(self, index):
        img_p = Path(self.img_ps[index])
        img = Image.open(img_p).convert("RGB")
        img = self.transform(img)
        return img


class VimeoLmdbDataset(data.Dataset):
    def __init__(self, root_dir, crop_size, idxes=None):
        self.root_dir = root_dir
        self.n_frames = 7
        self.idxes = idxes

        self.env, self.txn = None, None
        with lmdb.open(root_dir, readonly=True, lock=False,
                       readahead=False, meminit=False) as env:
            with env.begin(write=False) as txn:
                self.n_samples = int(txn.get("num-samples".encode()))

        self.transform = transforms.Compose([
            video_transforms.RandomCrop(crop_size),
            video_transforms.ToTensor()
        ])

    def _init_db(self):
        self.env = lmdb.open(self.root_dir, readonly=True, lock=False,
                             readahead=False, meminit=False)
        self.txn = self.env.begin(write=False)

    def __getitem__(self, index):
        if self.env is None:
            self._init_db()
        assert index < self.n_samples
        assert self.idxes is not None
        frames = []
        start = torch.randint(0, self.n_frames - max(self.idxes), [1]).item()
        for idx in self.idxes:
            frameKey = '{:0>9}-{:0>3}'.format(index + 1, start + idx + 1)
            img_bin = self.txn.get(frameKey.encode())
            frame = Image.open(io.BytesIO(img_bin))
            frame = frame.convert('RGB')
            frames.append(frame)
        frames = self.transform(frames)
        return frames

    def __len__(self):
        return self.n_samples